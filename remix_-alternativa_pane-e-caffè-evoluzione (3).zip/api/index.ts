import express, { Request, Response } from "express";
import Stripe from "stripe";
import { Resend } from "resend";

const app = express();
app.use(express.json());

let stripe: Stripe | null = null;
let resend: Resend | null = null;

const getStripe = (): Stripe => {
  if (!stripe) {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) {
      throw new Error("STRIPE_SECRET_KEY is required for payments");
    }
    stripe = new Stripe(key, {
      apiVersion: "2025-01-27.acacia" as any,
    });
  }
  return stripe;
};

const getResend = (): Resend | null => {
  if (!resend && process.env.RESEND_API_KEY) {
    resend = new Resend(process.env.RESEND_API_KEY);
  }
  return resend;
};

// Stripe Checkout API
app.post("/create-checkout-session", async (req: Request, res: Response) => {
  try {
    const { items, customerEmail, orderId } = req.body;
    
    const session = await getStripe().checkout.sessions.create({
      payment_method_types: ["card", "revolut_pay"],
      line_items: items.map((item: any) => ({
        price_data: {
          currency: "eur",
          product_data: {
            name: item.name,
            description: item.description || "",
          },
          unit_amount: Math.round(item.price * 100),
        },
        quantity: item.quantity,
      })),
      mode: "payment",
      customer_email: customerEmail || undefined,
      success_url: `${req.headers.origin}/?payment=success&orderId=${orderId}`,
      cancel_url: `${req.headers.origin}/?payment=cancel&orderId=${orderId}`,
      metadata: {
        orderId: orderId,
      },
    });

    res.json({ id: session.id, url: session.url });
  } catch (error: any) {
    console.error("Stripe Checkout Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// Notification API
app.post("/notify-order", async (req: Request, res: Response) => {
  try {
    const { order, items } = req.body;
    console.log("Notification request received for order:", order?.orderNumber);

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_RIDER_CHAT_ID;

    const firstName = order.firstName || order.customerInfo?.firstName || "Cliente";
    const lastName = order.lastName || order.customerInfo?.lastName || "";
    const phone = order.phone || order.customerInfo?.phone || "N/D";
    const address = order.address || order.customerInfo?.address || "N/D";
    const email = order.email || order.customerInfo?.email || "";
    const price = Number(order.totalPrice || 0).toFixed(2);

    if (botToken && chatId) {
      try {
        const message = `🍔 NUOVO ORDINE: ${order.orderNumber}\n👤 Cliente: ${firstName} ${lastName}\n📞 Tel: ${phone}\n📍 Tipo: ${order.deliveryType === "delivery" ? "CONSEGNA" : "RITIRO"}\n⏰ Orario: ${order.scheduledTime}\n💰 Totale: €${price}\n💳 Pagamento: ${order.paymentMethod === "card" ? "CARTA (Stripe)" : "CONTANTI"}\n🧾 Stato Pagamento: ${order.paymentStatus}\n\n🛒 PRODOTTI:\n${(items || []).map((it: any) => `- ${it.quantity}x ${it.productName}`).join("\n")}\n\n${order.deliveryType === "delivery" ? `🏠 Indirizzo: ${address}` : ""}\n${order.notes ? `📝 Note: ${order.notes}` : ""}`;

        await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
          }),
        });
      } catch (tgErr) {
        console.error("Telegram fetch exception:", tgErr);
      }
    }

    const resendClient = getResend();
    if (resendClient && email) {
      await resendClient.emails.send({
        from: 'Pane & Caffè <ordini@pane-caffe.it>',
        to: email,
        subject: `Conferma Ordine ${order.orderNumber} - Pane & Caffè`,
        html: `
          <h1>Grazie per il tuo ordine!</h1>
          <p>Ciao ${firstName}, il tuo ordine <strong>${order.orderNumber}</strong> è stato ricevuto.</p>
          <p><strong>Dettagli:</strong></p>
          <ul>
            <li>Tipo: ${order.deliveryType}</li>
            <li>Orario: ${order.scheduledTime}</li>
            <li>Totale: €${Number(order.totalPrice || 0).toFixed(2)}</li>
          </ul>
          <p>Ti aspettiamo!</p>
        `,
      }).catch(err => console.error("Email error:", err));
    }

    res.json({ status: "ok" });
  } catch (error: any) {
    console.error("Notification Error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.get("/health", (_req: Request, res: Response) => {
  res.json({ 
    status: "ok", 
    vercel: true,
    stripe: !!process.env.STRIPE_SECRET_KEY,
    telegram: !!process.env.TELEGRAM_BOT_TOKEN
  });
});

export default app;
