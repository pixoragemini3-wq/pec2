import { db } from '../lib/firebase';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  serverTimestamp 
} from 'firebase/firestore';

export interface UserProfile {
  firstName: string;
  lastName: string;
  phone: string;
  address?: string;
  email: string;
  isAdmin?: boolean;
  userCode?: string;
  updatedAt?: any;
}

export const userService = {
  generateUserCode(): string {
    const code = Math.floor(100000 + Math.random() * 900000);
    return `#${code}`;
  },

  async getProfile(uid: string): Promise<UserProfile | null> {
    const docRef = doc(db, 'users', uid);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as UserProfile;
    }
    return null;
  },

  async createProfile(uid: string, profile: Omit<UserProfile, 'updatedAt' | 'userCode'>): Promise<void> {
    const docRef = doc(db, 'users', uid);
    const userCode = this.generateUserCode();
    await setDoc(docRef, {
      ...profile,
      userCode,
      updatedAt: serverTimestamp()
    });
  },

  async updateProfile(uid: string, profile: Partial<UserProfile>): Promise<void> {
    const docRef = doc(db, 'users', uid);
    await updateDoc(docRef, {
      ...profile,
      updatedAt: serverTimestamp()
    });
  }
};
