import { 
  doc, 
  getDoc, 
  setDoc, 
  collection, 
  query, 
  where, 
  getDocs, 
  increment,
  runTransaction
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

export interface SchedulingConfig {
  maxOrdersPerSlot: number;
  disabledSlots: string[]; // List of slot times "HH:mm" or specific date_time "YYYY-MM-DD_HH:mm"
  workingHours: {
    start: string;
    end: string;
  };
}

export interface SlotAvailability {
  time: string;
  isAvailable: boolean;
  occupancy: number;
  maxCapacity: number;
}

export const schedulingService = {
  async getConfig(): Promise<SchedulingConfig> {
    try {
      const configDoc = await getDoc(doc(db, 'config', 'scheduling'));
      if (configDoc.exists()) {
        return configDoc.data() as SchedulingConfig;
      }
      // Default config
      return {
        maxOrdersPerSlot: 2,
        disabledSlots: [],
        workingHours: {
          start: "19:00",
          end: "23:55"
        }
      };
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, 'config/scheduling');
      throw error;
    }
  },

  async updateConfig(config: SchedulingConfig): Promise<void> {
    try {
      await setDoc(doc(db, 'config', 'scheduling'), config);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'config/scheduling');
      throw error;
    }
  },

  async getSlotOccupancy(date: string, time: string): Promise<number> {
    try {
      const slotId = `${date}_${time.replace(':', '-')}`;
      const slotDoc = await getDoc(doc(db, 'schedulingSlots', slotId));
      if (slotDoc.exists()) {
        return slotDoc.data().load || 0;
      }
      return 0;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, 'schedulingSlots');
      throw error;
    }
  },

  async getAllSlotsOccupancy(date: string): Promise<Record<string, number>> {
    try {
      const slotsRef = collection(db, 'schedulingSlots');
      const q = query(slotsRef, where('date', '==', date));
      const snapshot = await getDocs(q);
      
      const occupancy: Record<string, number> = {};
      snapshot.forEach(doc => {
        const data = doc.data();
        occupancy[data.time] = data.load || 0;
      });
      
      return occupancy;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'schedulingSlots');
      throw error;
    }
  },

  async reserveSlot(date: string, time: string, weight: number, maxCapacity: number): Promise<void> {
    const slotId = `${date}_${time.replace(':', '-')}`;
    const slotRef = doc(db, 'schedulingSlots', slotId);

    try {
      await runTransaction(db, async (transaction) => {
        const slotDoc = await transaction.get(slotRef);
        const currentLoad = slotDoc.exists() ? (slotDoc.data().load || 0) : 0;

        if (currentLoad >= maxCapacity) {
          throw new Error('Questo orario ha raggiunto la capacità massima. Per favore scegline un altro.');
        }

        if (!slotDoc.exists()) {
          transaction.set(slotRef, {
            date,
            time,
            load: weight
          });
        } else {
          transaction.update(slotRef, {
            load: increment(weight)
          });
        }
      });
    } catch (error) {
      if (error instanceof Error && error.message.includes('capacità massima')) {
        throw error;
      }
      handleFirestoreError(error, OperationType.WRITE, 'schedulingSlots/' + slotId);
      throw error;
    }
  }
};
