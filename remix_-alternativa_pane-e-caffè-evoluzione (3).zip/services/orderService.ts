import { db } from '../lib/firebase';
import { 
  collection, 
  addDoc, 
  serverTimestamp, 
  writeBatch,
  doc,
  query,
  where,
  orderBy,
  onSnapshot,
  updateDoc,
  deleteDoc,
  getDocs
} from 'firebase/firestore';
import { CartItem, Order, OrderCustomerInfo, OrderRecipientInfo } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

export interface OrderInfo {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  address?: string;
  deliveryType: 'pickup' | 'delivery';
  paymentMethod: 'delivery' | 'card';
  isForSomeoneElse: boolean;
  recipientInfo?: OrderRecipientInfo;
  scheduledTime?: string;
  estimatedPrepTime?: number;
}

export const orderService = {
  // Generate a random unique-ish order number in format PEC-YYMMDDXXX
  async generateOrderNumber() {
    try {
      const now = new Date();
      const yy = now.getFullYear().toString().slice(-2);
      const mm = (now.getMonth() + 1).toString().padStart(2, '0');
      const dd = now.getDate().toString().padStart(2, '0');
      const datePrefix = `${yy}${mm}${dd}`;
      
      // Get count of orders for today
      const startOfDay = new Date(now);
      startOfDay.setHours(0, 0, 0, 0);
      
      const q = query(
        collection(db, 'orders'),
        where('createdAt', '>=', startOfDay)
      );
      
      const snapshot = await getDocs(q);
      const count = snapshot.size + 1;
      const suffix = count.toString().padStart(3, '0');
      
      return `PEC-${datePrefix}${suffix}`;
    } catch (error) {
      console.error("Error generating order number:", error);
      // Fallback to random if something fails
      const random = Math.floor(Math.random() * 900) + 100;
      return `PEC-R${random}`;
    }
  },

  async createOrder(userId: string, items: CartItem[], total: number, orderInfo: OrderInfo) {
    try {
      const orderNumber = await this.generateOrderNumber();
      
      const customerInfo: OrderCustomerInfo = {
        firstName: orderInfo.firstName,
        lastName: orderInfo.lastName,
        phone: orderInfo.phone,
        email: orderInfo.email,
        address: orderInfo.address
      };

      const orderData: any = {
        userId,
        orderNumber,
        status: 'pending',
        paymentStatus: orderInfo.paymentMethod === 'card' ? 'pending' : 'unpaid',
        paymentMethod: orderInfo.paymentMethod,
        totalPrice: total,
        deliveryType: orderInfo.deliveryType,
        customerInfo,
        isForSomeoneElse: orderInfo.isForSomeoneElse,
        scheduledTime: orderInfo.scheduledTime,
        estimatedPrepTime: orderInfo.estimatedPrepTime,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      // Ensure no undefined fields are passed to Firestore
      if (orderInfo.isForSomeoneElse && orderInfo.recipientInfo) {
        orderData.recipientInfo = orderInfo.recipientInfo;
      }

      const orderRef = await addDoc(collection(db, 'orders'), orderData);

      // Save items in subcollection
      const batch = writeBatch(db);
      items.forEach(item => {
        const itemRef = doc(collection(db, `orders/${orderRef.id}/items`));
        
        // Clean up configuration to remove undefined values
        const config: any = {
          variant: item.variant || null,
          removedIngredients: item.removedIngredients || [],
          addedExtras: item.addedExtras || [],
          selectedFrySauces: item.selectedFrySauces || [],
          notes: item.notes || ""
        };

        if (item.selectedDrink) {
          config.selectedDrinkId = item.selectedDrink.id;
        }

        batch.set(itemRef, {
          productId: item.product.id,
          productName: item.product.name,
          quantity: item.quantity,
          priceAtPurchase: item.finalPrice,
          configuration: config
        });
      });

      await batch.commit();
      return { id: orderRef.id, orderNumber };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'orders');
      throw error;
    }
  },

  subscribeToUserOrders(userId: string, callback: (orders: Order[]) => void) {
    const q = query(
      collection(db, 'orders'), 
      where('userId', '==', userId), 
      orderBy('createdAt', 'desc')
    );
    
    return onSnapshot(q, (snapshot) => {
      const orders = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Order[];
      callback(orders);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'orders');
    });
  },

  async cancelOrder(orderId: string) {
    try {
      const orderRef = doc(db, 'orders', orderId);
      await updateDoc(orderRef, {
        status: 'cancelled',
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'orders/' + orderId);
    }
  },

  async updateOrderStatus(orderId: string, status: Order['status']) {
    try {
      const orderRef = doc(db, 'orders', orderId);
      await updateDoc(orderRef, {
        status,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'orders/' + orderId);
    }
  },

  async updatePaymentStatus(orderId: string, paymentStatus: Order['paymentStatus']) {
    try {
      const orderRef = doc(db, 'orders', orderId);
      await updateDoc(orderRef, {
        paymentStatus,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'orders/' + orderId);
    }
  }
};
