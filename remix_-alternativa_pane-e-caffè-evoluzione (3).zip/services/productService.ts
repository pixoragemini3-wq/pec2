import { db, storage } from '../lib/firebase';
import { 
  collection, 
  getDocs, 
  doc, 
  updateDoc, 
  setDoc,
  deleteDoc, 
  writeBatch
} from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { Product } from '../types';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

const COLLECTION_NAME = 'products';

export const productService = {
  async getProducts() {
    console.log("Fetching products from Firestore...");
    try {
      const q = collection(db, COLLECTION_NAME);
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) {
        console.log("Firestore empty, returning empty list (caller will fallback to constants)");
        return [];
      }

      const products = querySnapshot.docs.map(doc => {
        const data = doc.data();
        // Keep ID as number if it's numeric, otherwise string
        const id = isNaN(Number(doc.id)) ? doc.id : Number(doc.id);
        return { ...data, id } as Product;
      });

      console.log(`Fetched ${products.length} products from Firestore`);
      
      return products.sort((a, b) => {
        const idA = typeof a.id === 'number' ? (a.id as number) : 999999;
        const idB = typeof b.id === 'number' ? (b.id as number) : 999999;
        return idA - idB;
      });
    } catch (error) {
      console.error("Error in getProducts:", error);
      handleFirestoreError(error, OperationType.LIST, COLLECTION_NAME);
      return [];
    }
  },

  async updateProduct(id: string | number, updates: Partial<Product>) {
    const stringId = String(id);
    try {
      const productRef = doc(db, COLLECTION_NAME, stringId);
      await updateDoc(productRef, updates);
      const normalizedId = isNaN(Number(stringId)) ? stringId : Number(stringId);
      return { id: normalizedId, ...updates };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `${COLLECTION_NAME}/${stringId}`);
    }
  },

  async createProduct(product: Omit<Product, 'id'>) {
    console.log("Creating new product in Firestore...", product.name);
    try {
      const docRef = doc(collection(db, COLLECTION_NAME));
      const productId = docRef.id;
      const productWithId = { ...product, id: productId };
      console.log("Setting document with ID:", productId);
      await setDoc(docRef, productWithId);
      console.log("Product created successfully!");
      return productWithId as Product;
    } catch (error) {
      console.error("FATAL: createProduct failed:", error);
      handleFirestoreError(error, OperationType.CREATE, COLLECTION_NAME);
    }
  },

  async deleteProduct(id: string | number) {
    const stringId = String(id);
    try {
      await deleteDoc(doc(db, COLLECTION_NAME, stringId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${COLLECTION_NAME}/${stringId}`);
    }
  },

  async uploadImage(file: File): Promise<string> {
    if (!file) throw new Error("Nessun file selezionato");
    if (file.size > 5 * 1024 * 1024) throw new Error("File troppo grande (max 5MB)");

    console.log(`Starting resumable upload for: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`);
    
    const fileExt = file.name.split('.').pop() || 'jpg';
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = `product-images/${fileName}`;
    const storageRef = ref(storage, filePath);

    const uploadTask = uploadBytesResumable(storageRef, file);

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        uploadTask.cancel();
        reject(new Error("Timeout caricamento immagine (60s)"));
      }, 60000);

      uploadTask.on('state_changed',
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log(`Upload progress: ${progress.toFixed(0)}%`);
        },
        (error: any) => {
          clearTimeout(timeout);
          console.error('FIREBASE STORAGE ERROR:', error);
          let errorMsg = error.message || String(error);
          if (error.code === 'storage/unauthorized') {
            errorMsg = "Non hai i permessi per caricare immagini. Verifica le regole di Firebase Storage.";
          } else if (error.code === 'storage/canceled') {
            errorMsg = "Caricamento annullato o timeout.";
          }
          reject(new Error(errorMsg));
        },
        async () => {
          clearTimeout(timeout);
          try {
            const url = await getDownloadURL(uploadTask.snapshot.ref);
            console.log("Success! Image URL:", url);
            resolve(url);
          } catch (urlErr: any) {
            reject(new Error("Errore nel recupero dell'URL: " + urlErr.message));
          }
        }
      );
    });
  },

  async seedProducts(products: Product[]) {
    console.log("Seeding started for ", products.length, " products");
    try {
      const batch = writeBatch(db);
      let count = 0;
      
      // Limit to 450 to stay safe under 500 limit
      const itemsToProcess = products.slice(0, 450);
      
      itemsToProcess.forEach(p => {
        if (!p || p.id === undefined) return;
        
        const stringId = String(p.id);
        const productRef = doc(db, COLLECTION_NAME, stringId);
        
        // Pulizia dati rigorosa per Firestore
        const sanitizedData: any = {
          id: p.id,
          name: p.name || '',
          price: Number(p.price) || 0,
          category: p.category || 'hamburger',
          description: p.description || '',
          image: p.image || '',
          isVisible: p.isVisible !== false,
          updatedAt: new Date().toISOString()
        };

        // Add optional fields only if they exist and are not undefined
        if (p.ingredients) sanitizedData.ingredients = p.ingredients;
        if (p.removableIngredients) sanitizedData.removableIngredients = p.removableIngredients;
        if (p.extras) sanitizedData.extras = p.extras;
        if (p.variants) sanitizedData.variants = p.variants;
        if (p.menuPrice !== undefined) sanitizedData.menuPrice = Number(p.menuPrice);
        if (p.isDrink !== undefined) sanitizedData.isDrink = p.isDrink;
        if (p.availableDays) sanitizedData.availableDays = p.availableDays;
        
        batch.set(productRef, sanitizedData);
        count++;
      });
      
      console.log(`Committing batch for ${count} products...`);
      await batch.commit();
      console.log("Batch committed successfully");
      return true;
    } catch (error) {
      console.warn("seedProducts failed (expected if not admin):", error);
      return false;
    }
  },
};
