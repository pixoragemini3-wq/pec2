import { GoogleGenAI, Type } from "@google/genai";

let genAI: GoogleGenAI | null = null;

function getGenAI() {
  if (!genAI) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY non configurata. Assicurati che sia presente nell'ambiente.");
    }
    genAI = new GoogleGenAI({ apiKey });
  }
  return genAI;
}

export interface SuggestionResult {
  suggestedIngredients: string[];
  suggestedRemovable: string[];
  suggestedExtras: { name: string; price: number }[];
}

export const geminiService = {
  async suggestCustomizations(productName: string, description: string): Promise<SuggestionResult> {
    try {
      const ai = getGenAI();
      const prompt = `Analizza questo prodotto di una panineria/hamburgheria italiana:
Nome: ${productName}
Descrizione: ${description}

Fornisci tre liste:
1. "suggestedIngredients": Gli ingredienti principali che compongono il panino.
2. "suggestedRemovable": Quali di questi ingredienti hanno senso essere rimossi su richiesta del cliente (es. cipolla, salse, insalata).
3. "suggestedExtras": Ingredienti extra o salse che starebbero bene come aggiunta a pagamento in questo panino specifico.

Rispondi SOLO in formato JSON.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              suggestedIngredients: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              suggestedRemovable: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              suggestedExtras: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    price: { type: Type.NUMBER }
                  },
                  required: ["name", "price"]
                }
              }
            },
            required: ["suggestedIngredients", "suggestedRemovable", "suggestedExtras"]
          }
        }
      });

      const text = response.text;
      if (!text) throw new Error("Nessuna risposta da AI");
      return JSON.parse(text) as SuggestionResult;
    } catch (error) {
      console.error("Gemini Suggestion Error:", error);
      throw error;
    }
  }
};
