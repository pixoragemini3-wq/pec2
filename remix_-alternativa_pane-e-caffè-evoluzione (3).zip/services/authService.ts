import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut as firebaseSignOut 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';

const googleProvider = new GoogleAuthProvider();

export const authService = {
  async signInWithGoogle() {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;

      // Crea o aggiorna il profilo utente
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);

      const isAdminEmail = user.email === 'downloandroid@gmail.com';

      if (!userSnap.exists()) {
        await setDoc(userRef, {
          fullName: user.displayName,
          email: user.email,
          phone: null,
          address: null,
          isAdmin: isAdminEmail,
          createdAt: serverTimestamp(),
          photoURL: user.photoURL
        });
      } else if (isAdminEmail && !userSnap.data()?.isAdmin) {
        // Forza isAdmin se l'utente esiste già ma non è admin
        await setDoc(userRef, { isAdmin: true }, { merge: true });
      }

      return user;
    } catch (error) {
      console.error('Error signing in with Google:', error);
      throw error;
    }
  },

  async signOut() {
    try {
      await firebaseSignOut(auth);
    } catch (error) {
      console.error('Error signing out:', error);
      throw error;
    }
  }
};
