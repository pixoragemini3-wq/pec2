import { db } from '../lib/firebase';
import { 
  doc, 
  getDoc, 
  setDoc,
  onSnapshot
} from 'firebase/firestore';

export interface AppSettings {
  mobileColumns: 1 | 2;
  desktopColumns: 3 | 4;
}

const DEFAULT_SETTINGS: AppSettings = {
  mobileColumns: 2,
  desktopColumns: 4
};

const SETTINGS_DOC_PATH = 'config/app_settings';

export const settingsService = {
  async getSettings(): Promise<AppSettings> {
    try {
      const docRef = doc(db, SETTINGS_DOC_PATH);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data() as AppSettings;
      }
      return DEFAULT_SETTINGS;
    } catch (error) {
      console.error("Error fetching settings:", error);
      return DEFAULT_SETTINGS;
    }
  },

  async updateSettings(settings: Partial<AppSettings>): Promise<void> {
    const docRef = doc(db, SETTINGS_DOC_PATH);
    const current = await this.getSettings();
    await setDoc(docRef, { ...current, ...settings }, { merge: true });
  },

  subscribeToSettings(callback: (settings: AppSettings) => void) {
    const docRef = doc(db, SETTINGS_DOC_PATH);
    return onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        callback(docSnap.data() as AppSettings);
      } else {
        callback(DEFAULT_SETTINGS);
      }
    });
  }
};
