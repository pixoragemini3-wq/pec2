import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { CartItem, Product, CartItemVariant, SelectedExtra } from '../types';

interface CartContextType {
  cartItems: CartItem[];
  cartCount: number;
  totalPrice: number;
  addToCart: (item: Omit<CartItem, 'id'>) => void;
  updateQuantity: (id: string, quantity: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  generateCartItemId: (item: Omit<CartItem, 'id' | 'quantity'>) => string;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
};

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const savedCart = localStorage.getItem('paneECaffeCart');
      return savedCart ? JSON.parse(savedCart) : [];
    } catch (error) {
      console.error("Could not parse cart from localStorage", error);
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('paneECaffeCart', JSON.stringify(cartItems));
  }, [cartItems]);

  const generateCartItemId = (item: Omit<CartItem, 'id' | 'quantity'>): string => {
    const parts: string[] = [
        `p_${item.product.id}`,
        `v_${item.variant}`,
    ];

    if (item.removedIngredients.length > 0) {
        parts.push(`r_${[...item.removedIngredients].sort().join(',')}`);
    }
    if (item.addedExtras.length > 0) {
        parts.push(`a_${[...item.addedExtras].map(e => e.name).sort().join(',')}`);
    }
    if (item.selectedDrink) {
        parts.push(`d_${item.selectedDrink.id}`);
    }
    if (item.selectedFrySauces && item.selectedFrySauces.length > 0) {
        parts.push(`s_${[...item.selectedFrySauces].sort().join(',')}`);
    }
    if (item.notes.trim()) {
        parts.push(`n_${item.notes.trim()}`);
    }

    return parts.join('|');
  };

  const addToCart = useCallback((item: Omit<CartItem, 'id'>) => {
    setCartItems(prev => {
      const existingItemIndex = prev.findIndex(i => generateCartItemId(i) === generateCartItemId(item));
      if (existingItemIndex > -1) {
        const newItems = [...prev];
        newItems[existingItemIndex].quantity += item.quantity;
        return newItems;
      }
      return [...prev, { ...item, id: Math.random().toString(36).substr(2, 9) }];
    });
  }, []);

  const updateQuantity = useCallback((id: string, quantity: number) => {
    setCartItems(prev => 
      prev.map(item => item.id === id ? { ...item, quantity: Math.max(0, quantity) } : item)
          .filter(item => item.quantity > 0)
    );
  }, []);

  const removeFromCart = useCallback((id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  }, []);

  const clearCart = useCallback(() => {
    setCartItems([]);
  }, []);

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cartItems.reduce((sum, item) => sum + item.finalPrice * item.quantity, 0);

  return (
    <CartContext.Provider value={{ 
      cartItems, 
      cartCount, 
      totalPrice, 
      addToCart, 
      updateQuantity, 
      removeFromCart, 
      clearCart,
      generateCartItemId
    }}>
      {children}
    </CartContext.Provider>
  );
};
