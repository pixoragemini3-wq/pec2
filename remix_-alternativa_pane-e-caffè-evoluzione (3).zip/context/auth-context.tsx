import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signOut as firebaseSignOut } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, onSnapshot, setDoc, serverTimestamp } from 'firebase/firestore';
import { Profile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  isAdmin: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      // Cleanup previous profile subscription if auth state changes
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (currentUser) {
        const userRef = doc(db, 'users', currentUser.uid);
        const snap = await getDoc(userRef);
        
        if (!snap.exists()) {
          const [firstName, ...lastNameParts] = (currentUser.displayName || '').split(' ');
          const userCode = `#${Math.floor(100000 + Math.random() * 900000)}`;
          await setDoc(userRef, {
            firstName: firstName || '',
            lastName: lastNameParts.join(' ') || '',
            email: currentUser.email,
            isAdmin: currentUser.email === 'downloandroid@gmail.com' || currentUser.email === 'pixoragemini3@gmail.com',
            userCode,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
        } else {
          const profileData = snap.data();
          const updates: any = {};
          
          if (!profileData?.userCode) {
            updates.userCode = `#${Math.floor(100000 + Math.random() * 900000)}`;
          }
          
          if (currentUser.email === 'downloandroid@gmail.com' || currentUser.email === 'pixoragemini3@gmail.com') {
            if (profileData?.isAdmin !== true) {
              updates.isAdmin = true;
            }
          }
          
          if (Object.keys(updates).length > 0) {
            await setDoc(userRef, updates, { merge: true });
          }
        }

        // Usa onSnapshot per avere il profilo sempre aggiornato
        const profileRef = doc(db, 'users', currentUser.uid);
        unsubscribeProfile = onSnapshot(profileRef, (docSnap) => {
          if (docSnap.exists()) {
            setProfile({ id: docSnap.id, ...docSnap.data() } as Profile);
          } else {
            setProfile(null);
          }
          setLoading(false);
        }, (error) => {
          console.error("Profile onSnapshot error:", error);
          setLoading(false);
        });
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  const signOut = async () => {
    await firebaseSignOut(auth);
  };

  const value = {
    user,
    profile,
    loading,
    isAdmin: profile?.isAdmin || false,
    signOut
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
