import React, { useState } from 'react';
import { useAuth } from '../context/auth-context';
import { motion, AnimatePresence } from 'motion/react';
import { X, User, Package, LogOut, ChevronRight } from 'lucide-react';
import UserProfile from './UserProfile';
import UserOrders from './UserOrders';

interface UserAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const UserAccountModal: React.FC<UserAccountModalProps> = ({ isOpen, onClose }) => {
  const { user, profile, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState<'profile' | 'orders'>('orders');

  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-brand-cream w-full max-w-4xl rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]"
      >
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-white border-r border-gray-100 flex flex-col">
          <div className="p-6 border-b border-gray-50">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full border-2 border-brand-red/20 overflow-hidden shrink-0">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="User" className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full bg-brand-red/10 flex items-center justify-center">
                    <User className="h-6 w-6 text-brand-red" />
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <p className="font-bold text-brand-dark truncate leading-tight">
                  {profile?.firstName ? `${profile.firstName} ${profile.lastName}` : (user.displayName || 'Utente')}
                </p>
                <p className="text-[10px] text-brand-red truncate uppercase tracking-widest font-extrabold flex items-center gap-1">
                   {profile?.userCode || 'Cliente'}
                </p>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-1">
            <button 
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                activeTab === 'orders' ? 'bg-brand-red text-white shadow-md shadow-brand-red/20' : 'text-gray-500 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <Package className="h-5 w-5" />
                <span className="font-bold text-sm uppercase tracking-wide">I Miei Ordini</span>
              </div>
              <ChevronRight className={`h-4 w-4 transition-transform ${activeTab === 'orders' ? 'rotate-90' : ''}`} />
            </button>
            <button 
              onClick={() => setActiveTab('profile')}
              className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                activeTab === 'profile' ? 'bg-brand-red text-white shadow-md shadow-brand-red/20' : 'text-gray-500 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <User className="h-5 w-5" />
                <span className="font-bold text-sm uppercase tracking-wide">Profilo</span>
              </div>
              <ChevronRight className={`h-4 w-4 transition-transform ${activeTab === 'profile' ? 'rotate-90' : ''}`} />
            </button>
          </nav>

          <div className="p-4 border-t border-gray-50">
            <button 
              onClick={() => {
                if(confirm('Vuoi disconnetterti?')) {
                  signOut();
                  onClose();
                }
              }}
              className="w-full flex items-center gap-3 p-3 text-red-500 hover:bg-red-50 rounded-xl transition-all font-bold text-sm uppercase tracking-wide"
            >
              <LogOut className="h-5 w-5" />
              Logout
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0 bg-gray-50/50">
          <div className="p-4 flex items-center justify-between md:hidden border-b border-gray-100 bg-white">
             <h2 className="font-bebas text-xl text-brand-dark tracking-wider">
               {activeTab === 'orders' ? 'I Miei Ordini' : 'Profilo'}
             </h2>
             <button onClick={onClose} className="p-2 bg-gray-100 rounded-full">
               <X className="h-5 w-5" />
             </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 md:p-8">
            <div className="max-w-2xl mx-auto">
              {activeTab === 'orders' ? (
                <UserOrders />
              ) : (
                <UserProfile />
              )}
            </div>
          </div>

          {/* Desktop Close */}
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 p-2 bg-white rounded-full shadow-md text-gray-400 hover:text-brand-red transition-colors hidden md:block"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default UserAccountModal;
