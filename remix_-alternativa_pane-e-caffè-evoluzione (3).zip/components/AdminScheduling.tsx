import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { schedulingService, SchedulingConfig } from '../services/schedulingService';
import { Clock, Save, Ban, CheckCircle2, ChevronLeft, ChevronRight, Calendar, Truck, Store } from 'lucide-react';
import { Order } from '../types';

const AdminScheduling: React.FC = () => {
  const [config, setConfig] = useState<SchedulingConfig | null>(null);
  const [occupancy, setOccupancy] = useState<Record<string, number>>({});
  const [currentDate, setCurrentDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    loadData();
    
    // Subscribe to orders for the current day
    const startOfDay = new Date(currentDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(currentDate);
    endOfDay.setHours(23, 59, 59, 999);

    const q = query(
      collection(db, 'orders'),
      where('createdAt', '>=', startOfDay),
      where('createdAt', '<=', endOfDay),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Order[];
      setOrders(ordersData);
    });

    return () => unsubscribe();
  }, [currentDate]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [conf, occ] = await Promise.all([
        schedulingService.getConfig(),
        schedulingService.getAllSlotsOccupancy(currentDate)
      ]);
      setConfig(conf);
      setOccupancy(occ);
    } catch (err) {
      console.error("Error loading scheduling data:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveConfig = async () => {
    if (!config) return;
    setSaving(true);
    try {
      await schedulingService.updateConfig(config);
      alert('Configurazione salvata con successo!');
    } catch (err) {
      alert('Errore durante il salvataggio.');
    } finally {
      setSaving(false);
    }
  };

  const toggleSlot = async (time: string) => {
    if (!config) return;
    try {
      const isCurrentlyDisabled = config.disabledSlots.includes(time);
      const newDisabled = isCurrentlyDisabled
        ? config.disabledSlots.filter(t => t !== time)
        : [...config.disabledSlots, time];
      
      const newConfig = { ...config, disabledSlots: newDisabled };
      setConfig(newConfig);
      await schedulingService.updateConfig(newConfig);
    } catch (err) {
      console.error("Error toggling slot:", err);
      alert('Errore durante il salvataggio.');
    }
  };

  const generateAllDaySlots = () => {
    const slots = [];
    const [startH, startM] = (config?.workingHours.start || "19:00").split(':').map(Number);
    const [endH, endM] = (config?.workingHours.end || "23:55").split(':').map(Number);
    
    // Use a fixed date for generation to avoid "now" shift issues
    let current = new Date(2000, 0, 1, startH, startM, 0, 0);
    const end = new Date(2000, 0, 1, endH, endM, 0, 0);

    while (current <= end) {
      const timeStr = `${current.getHours().toString().padStart(2, '0')}:${current.getMinutes().toString().padStart(2, '0')}`;
      slots.push({
        time: timeStr,
        hour: current.getHours().toString().padStart(2, '0')
      });
      current = new Date(current.getTime() + 5 * 60000);
    }
    return slots;
  };

  if (loading && !config) return <div className="text-center py-12">Caricamento...</div>;

  return (
    <div className="space-y-8">
      {/* Global Config */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
            <Clock className="h-5 w-5 text-brand-red" /> Configurazione Globale
          </h3>
          <button 
            onClick={handleSaveConfig}
            disabled={saving}
            className="flex items-center gap-2 bg-brand-red text-white px-4 py-2 rounded-lg font-bold hover:bg-brand-red/90 transition-all text-sm disabled:opacity-50"
          >
            <Save className="h-4 w-4" /> {saving ? 'Salvataggio...' : 'Salva Impostazioni'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-600">Capacità Massima di Carico per Fascia (5 min)</label>
            <input 
              type="number" 
              value={config?.maxOrdersPerSlot || 2}
              onChange={(e) => setConfig(prev => prev ? {...prev, maxOrdersPerSlot: parseInt(e.target.value)} : null)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red"
            />
            <p className="text-[10px] text-gray-400 italic">Esempio: 1 panino semplice = 1, 1 panino complesso = 2.</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-600">Inizio Servizio</label>
              <input 
                type="time" 
                value={config?.workingHours.start || "19:00"}
                onChange={(e) => setConfig(prev => prev ? {...prev, workingHours: {...prev.workingHours, start: e.target.value}} : null)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-600">Fine Servizio</label>
              <input 
                type="time" 
                value={config?.workingHours.end || "23:55"}
                onChange={(e) => setConfig(prev => prev ? {...prev, workingHours: {...prev.workingHours, end: e.target.value}} : null)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Slots Management */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
          <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
            <Calendar className="h-5 w-5 text-brand-red" /> Gestione Fasce Orarie
          </h3>
          <div className="flex items-center gap-4 bg-gray-50 p-1 rounded-xl border border-gray-100">
            <button 
              onClick={() => {
                const date = new Date(currentDate);
                date.setDate(date.getDate() - 1);
                setCurrentDate(date.toISOString().split('T')[0]);
              }}
              className="p-2 hover:bg-white rounded-lg transition-all"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="font-bold text-sm min-w-[100px] text-center">
              {new Date(currentDate).toLocaleDateString('it-IT', { day: 'numeric', month: 'long' })}
            </span>
            <button 
              onClick={() => {
                const date = new Date(currentDate);
                date.setDate(date.getDate() + 1);
                setCurrentDate(date.toISOString().split('T')[0]);
              }}
              className="p-2 hover:bg-white rounded-lg transition-all"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="space-y-8">
          {Object.entries(
            generateAllDaySlots().reduce((acc, slot) => {
              if (!acc[slot.hour]) acc[slot.hour] = [];
              acc[slot.hour].push(slot);
              return acc;
            }, {} as Record<string, {time: string, hour: string}[]>)
          ).sort(([a], [b]) => a.localeCompare(b)).map(([hour, slots]) => (
            <div key={hour} className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bebas text-brand-red tracking-wide">Ore {hour}:00</span>
                <div className="h-px flex-1 bg-gray-100"></div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6 gap-3">
                {slots.map(({ time }) => {
                  const isDisabled = config?.disabledSlots.includes(time);
                  const slotOccupancy = occupancy[time] || 0;
                  const maxCap = config?.maxOrdersPerSlot || 2;
                  const isFull = slotOccupancy >= maxCap;

                  return (
                    <button
                      key={time}
                      onClick={() => toggleSlot(time)}
                      className={`p-3 rounded-xl border-2 transition-all text-left flex flex-col gap-1 relative ${
                        isDisabled 
                          ? 'border-gray-200 bg-gray-100 text-gray-400' 
                          : isFull 
                            ? 'border-orange-200 bg-orange-50'
                            : 'border-green-100 bg-green-50/30 hover:border-green-200'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-sm">{time}</span>
                        {isDisabled ? (
                          <Ban className="h-3 w-3 text-red-400" />
                        ) : (
                          <CheckCircle2 className={`h-3 w-3 ${isFull ? 'text-orange-500' : 'text-green-500'}`} />
                        )}
                      </div>
                      <div className="flex flex-col gap-0.5 mt-1">
                        <div className="flex justify-between text-[10px] font-medium">
                          <span>{isDisabled ? 'Disabilitato' : isFull ? 'SATURO' : 'Disponibile'}</span>
                          {!isDisabled && <span>{slotOccupancy}/{maxCap}</span>}
                        </div>
                        {!isDisabled && (
                          <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-full transition-all ${isFull ? 'bg-orange-500' : 'bg-green-500'}`}
                              style={{ width: `${Math.min((slotOccupancy / maxCap) * 100, 100)}%` }}
                            />
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
        <p className="mt-6 text-xs text-gray-500 italic">
          * Clicca su una fascia oraria per disattivarla o riattivarla istantaneamente (non dimenticare di salvare la configurazione globale se cambi i parametri generali).
        </p>
      </div>

      {/* Orders Timeline */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2">
          <Clock className="h-5 w-5 text-brand-red" /> Timeline Ordini ({orders.length})
        </h3>

        {orders.length === 0 ? (
          <div className="text-center py-12 text-gray-400 text-sm italic">
            Nessun ordine programmato per questa data.
          </div>
        ) : (
          <div className="space-y-4">
            {generateAllDaySlots().filter(slot => orders.some(o => o.scheduledTime === slot.time)).map(slot => {
              const slotOrders = orders.filter(o => o.scheduledTime === slot.time);
              return (
                <div key={slot.time} className="flex gap-4">
                  <div className="w-16 pt-1 text-sm font-bold text-brand-red shrink-0">{slot.time}</div>
                  <div className="flex-1 space-y-2">
                    {slotOrders.map(order => (
                      <div key={order.id} className="bg-gray-50 rounded-xl p-3 border border-gray-100 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${order.deliveryType === 'delivery' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'}`}>
                            {order.deliveryType === 'delivery' ? <Truck className="h-4 w-4" /> : <Store className="h-4 w-4" />}
                          </div>
                          <div>
                            <p className="text-sm font-bold">{order.customerInfo.firstName} {order.customerInfo.lastName}</p>
                            <p className="text-[10px] text-gray-500">#{order.orderNumber} • €{order.totalPrice.toFixed(2)}</p>
                          </div>
                        </div>
                        <div className={`text-[10px] font-bold px-2 py-1 rounded-full border ${
                          order.status === 'completed' ? 'bg-green-50 text-green-600 border-green-100' : 
                          order.status === 'cancelled' ? 'bg-red-50 text-red-600 border-red-100' : 
                          'bg-yellow-50 text-yellow-600 border-yellow-100'
                        }`}>
                          {order.status.toUpperCase()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminScheduling;
