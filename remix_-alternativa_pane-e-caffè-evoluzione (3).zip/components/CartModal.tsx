import React, { useMemo } from 'react';
import { CartItem } from '../types';
import XMarkIcon from './icons/XMarkIcon';
import TrashIcon from './icons/TrashIcon';
import QuantitySelector from './QuantitySelector';
import ArrowRightIcon from './icons/ArrowRightIcon';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (itemId: string, newQuantity: number) => void;
  onRemoveItem: (itemId: string) => void;
  onClearCart: () => void;
  onCheckout: () => void;
}

const CartModal: React.FC<CartModalProps> = ({ 
  isOpen, 
  onClose, 
  cartItems, 
  onUpdateQuantity, 
  onRemoveItem, 
  onClearCart,
  onCheckout
}) => {
  const baseTotalPrice = useMemo(() => {
    return cartItems.reduce((total, item) => total + item.finalPrice * item.quantity, 0);
  }, [cartItems]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex justify-center items-center p-4 pt-[calc(1rem+env(safe-area-inset-top))]">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-lg max-h-[calc(100vh-2rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center p-4 border-b border-brand-red/10">
          <h2 className="text-3xl font-bebas tracking-wide text-brand-dark">Riepilogo Ordine</h2>
          <button 
            onClick={onClose} 
            className="p-2.5 rounded-full bg-gray-100 hover:bg-brand-red text-brand-dark hover:text-white transition-all duration-300 shadow-sm hover:shadow-md active:scale-90 group flex items-center justify-center" 
            aria-label="Chiudi carrello"
          >
            <XMarkIcon className="h-7 w-7 transition-transform duration-300 group-hover:rotate-90" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto scrollbar-hide relative flex flex-col bg-white">
          <div className="p-4 flex-grow">
              {cartItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <TrashIcon className="h-10 w-10 text-gray-300" />
                  </div>
                  <p className="text-gray-400 font-bold uppercase tracking-widest text-sm">Il carrello è vuoto</p>
                  <button 
                    onClick={onClose}
                    className="mt-4 text-brand-red font-bold text-xs uppercase tracking-widest hover:underline"
                  >
                    Torna al Menù
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex justify-end mb-2">
                    <button onClick={onClearCart} className="text-xs font-bold uppercase tracking-widest text-red-500 hover:text-red-400 flex items-center gap-1">
                      <TrashIcon className="h-3 w-3" /> Svuota
                    </button>
                  </div>
                  <ul className="divide-y border-brand-red/10">
                    {cartItems.map(item => (
                        <li key={item.id} className="py-4 flex items-start space-x-4">
                          <img src={item.product.image} alt={item.product.name} className={`w-16 h-16 ${item.product.imageFit === 'cover' ? 'object-cover' : 'object-contain'} rounded-md bg-brand-red/5 p-1 shrink-0`} />
                          <div className="flex-grow min-w-0">
                            <p className="font-bold text-brand-dark truncate">{item.product.name} {item.variant === 'menu' ? '(Menù)' : ''}</p>
                            <div className="text-[10px] text-gray-600 space-y-0.5 mt-1">
                                {item.variant === 'menu' && <p>Bibita: {item.selectedDrink?.name}</p>}
                                {item.removedIngredients.length > 0 && <p className="text-red-400">Senza: {item.removedIngredients.join(', ')}</p>}
                                {item.addedExtras.length > 0 && <p className="text-green-500">Extra: {item.addedExtras.map(e => e.name).join(', ')}</p>}
                                {item.selectedFrySauces && item.selectedFrySauces.length > 0 && <p>Salse: {item.selectedFrySauces.join(', ')}</p>}
                                {item.notes && <p>Nota: <em className="text-brand-dark">{item.notes}</em></p>}
                            </div>
                          </div>
                          <div className="flex flex-col items-end space-y-1">
                            <span className="text-lg font-bebas text-brand-red tracking-wider">€{(item.finalPrice * item.quantity).toFixed(2)}</span>
                            <div className="flex items-center gap-2">
                              <QuantitySelector 
                                quantity={item.quantity} 
                                onQuantityChange={(newQuantity) => onUpdateQuantity(item.id, newQuantity)} 
                              />
                              <button onClick={() => onRemoveItem(item.id)} className="p-1 text-gray-400 hover:text-red-500 transition-colors" aria-label="Rimuovi"><TrashIcon className="h-4 w-4"/></button>
                            </div>
                          </div>
                        </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
            
            {cartItems.length > 0 && (
                <div className="p-6 border-t border-brand-red/10 bg-gray-50 sticky bottom-0 z-10">
                     <div className="flex justify-between items-center mb-4">
                        <span className="text-gray-400 font-bold uppercase text-xs tracking-widest">Subtotale</span>
                        <span className="text-2xl font-bebas text-brand-dark tracking-wider">€{baseTotalPrice.toFixed(2)}</span>
                     </div>
                     <button
                        onClick={onCheckout}
                        className="w-full bg-brand-red text-white font-bebas tracking-widest text-xl py-4 px-6 rounded-xl hover:bg-brand-red/90 transition-all duration-300 flex items-center justify-center gap-3 shadow-lg shadow-brand-red/20 active:scale-95"
                    >
                      <ArrowRightIcon className="h-6 w-6" />
                      <span>Procedi all'Ordine</span>
                    </button>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default CartModal;
