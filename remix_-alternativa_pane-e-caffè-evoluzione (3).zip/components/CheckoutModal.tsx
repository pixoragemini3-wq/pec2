import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/auth-context';
import { useCart } from '../context/cart-context';
import { orderService, OrderInfo } from '../services/orderService';
import { userService } from '../services/userService';
import { schedulingService, SchedulingConfig } from '../services/schedulingService';
import { motion, AnimatePresence } from 'motion/react';
import { loadStripe } from '@stripe/stripe-js';
import { 
  X, 
  ChevronRight, 
  ChevronLeft, 
  CreditCard, 
  Truck, 
  Store, 
  User, 
  MapPin, 
  AlertCircle,
  Gift,
  Clock,
  Calendar,
  Lock
} from 'lucide-react';

// Stripe redirect is handled via backend URL, so loadStripe is optional here
// const stripePromise = loadStripe((import.meta as any).env.VITE_STRIPE_PUBLISHABLE_KEY || '');

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (orderId: string) => void;
}

type CheckoutStep = 'details' | 'scheduling' | 'payment' | 'processing';

const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { user, profile } = useAuth();
  const { cartItems, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState<CheckoutStep>('details');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [occupancy, setOccupancy] = useState<Record<string, number>>({});
  const [schedConfig, setSchedConfig] = useState<SchedulingConfig | null>(null);

  useEffect(() => {
    // Handle Stripe redirect results if any
    const urlParams = new URLSearchParams(window.location.search);
    const payment = urlParams.get('payment');
    const orderIdParam = urlParams.get('orderId');

    if (payment === 'success' && orderIdParam) {
      onSuccess(orderIdParam);
      // Clean up URL
      window.history.replaceState({}, '', window.location.pathname);
    } else if (payment === 'cancel') {
       setError("Pagamento annullato. Riprova o scegli un altro metodo.");
       window.history.replaceState({}, '', window.location.pathname);
    }
  }, [onSuccess]);

  useEffect(() => {
    if (step === 'scheduling' && isOpen) {
      const today = new Date().toISOString().split('T')[0];
      schedulingService.getConfig().then(setSchedConfig);
      schedulingService.getAllSlotsOccupancy(today).then(setOccupancy);
    }
  }, [step, isOpen]);

  const [orderInfo, setOrderInfo] = useState<OrderInfo>({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    address: '',
    deliveryType: 'pickup',
    paymentMethod: 'delivery',
    isForSomeoneElse: false,
    recipientInfo: {
      name: '',
      phone: '',
      address: ''
    },
    scheduledTime: '',
    estimatedPrepTime: 0
  });

  // Calculate estimated prep time based on cart items
  const estimatedPrepTime = useMemo(() => {
    let time = 5; // Base time
    
    cartItems.forEach(item => {
      const name = item.product.name.toLowerCase();
      const isComplex = name.includes('truffle') || 
                        name.includes('signore') || 
                        name.includes('corn porn') || 
                        item.addedExtras.length > 2;
      
      const itemQuantity = item.quantity;
      
      if (item.product.category === 'hamburger' || item.product.category === 'panini-del-mese') {
        time += (isComplex ? 4 : 2) * itemQuantity;
      } else if (item.product.category.includes('chips') || item.product.category === 'starter') {
        time += 1 * itemQuantity;
      }
    });

    // Cap it slightly based on the examples (Max ~20-25 mins for very large orders)
    return Math.min(time, 30);
  }, [cartItems]);

  useEffect(() => {
    setOrderInfo(prev => ({ ...prev, estimatedPrepTime }));
  }, [estimatedPrepTime]);

  // Calculate order weight (load units) based on menu complexity
  const orderWeight = useMemo(() => {
    let weight = 0;
    cartItems.forEach(item => {
      const name = item.product.name.toLowerCase();
      const isComplex = name.includes('truffle') || 
                        name.includes('signore') || 
                        name.includes('corn porn') || 
                        item.addedExtras.length > 2;
      
      const itemQuantity = item.quantity;
      if (item.product.category === 'hamburger' || item.product.category === 'panini-del-mese') {
        weight += (isComplex ? 2 : 1) * itemQuantity;
      } else {
        weight += 0.5 * itemQuantity;
      }
    });
    return Math.ceil(weight);
  }, [cartItems]);

  // Generate available time slots (every 5 minutes starting from now + prep time)
  const timeSlots = useMemo(() => {
    const slots = [];
    const now = new Date();
    
    // Start from now + prep time, rounded up to the next 5 mins
    const minDelay = Math.max(estimatedPrepTime, 15); // At least 15 mins from now
    let startTime = new Date(now.getTime() + minDelay * 60000);

    // Ensure we don't show slots before opening time
    const [startH, startM] = (schedConfig?.workingHours.start || "19:00").split(':').map(Number);
    const openingTime = new Date(now);
    openingTime.setHours(startH, startM, 0, 0);

    if (startTime < openingTime) {
      startTime = new Date(openingTime);
    }

    const minutes = startTime.getMinutes();
    const roundedMinutes = Math.ceil(minutes / 5) * 5;
    startTime.setMinutes(roundedMinutes);
    startTime.setSeconds(0);
    startTime.setMilliseconds(0);

    // End time (e.g. 23:55)
    const endTime = new Date(now);
    if (schedConfig) {
      const [endH, endM] = schedConfig.workingHours.end.split(':').map(Number);
      endTime.setHours(endH, endM, 0, 0);
    } else {
      endTime.setHours(23, 55, 0, 0);
    }

    // Generate slots until end of day
    let current = new Date(startTime);
    while (current <= endTime) {
      const hours = current.getHours().toString().padStart(2, '0');
      const mins = current.getMinutes().toString().padStart(2, '0');
      const timeStr = `${hours}:${mins}`;
      
      const slotOccupancy = occupancy[timeStr] || 0;
      const maxCapacity = schedConfig?.maxOrdersPerSlot || 5;
      const isDisabled = schedConfig?.disabledSlots.includes(timeStr);

      slots.push({
        time: timeStr,
        hour: hours,
        isAvailable: !isDisabled && slotOccupancy < maxCapacity,
        occupancy: slotOccupancy,
        maxCapacity
      });

      current = new Date(current.getTime() + 5 * 60000);
    }

    return slots;
  }, [estimatedPrepTime, occupancy, schedConfig, orderWeight]);

  // Group slots by hour
  const groupedSlots = useMemo(() => {
    const groups: Record<string, typeof timeSlots> = {};
    timeSlots.forEach(slot => {
      if (!groups[slot.hour]) groups[slot.hour] = [];
      groups[slot.hour].push(slot);
    });
    return groups;
  }, [timeSlots]);

  useEffect(() => {
    if (profile) {
      setOrderInfo(prev => ({
        ...prev,
        firstName: profile.firstName || '',
        lastName: profile.lastName || '',
        phone: profile.phone || '',
        email: profile.email || '',
        address: profile.address || '',
        recipientInfo: prev.recipientInfo || { name: '', phone: '', address: '' }
      }));
    } else if (user) {
       setOrderInfo(prev => ({
        ...prev,
        email: user.email || '',
        recipientInfo: prev.recipientInfo || { name: '', phone: '', address: '' }
      }));
    }
  }, [profile, user]);

  if (!isOpen) return null;

  const validateDetails = () => {
    if (!orderInfo.firstName || !orderInfo.lastName || !orderInfo.phone) {
      setError('Inserisci nome, cognome e telefono.');
      return false;
    }
    if (orderInfo.deliveryType === 'delivery' && !orderInfo.address && !orderInfo.isForSomeoneElse) {
      setError('Inserisci un indirizzo per la consegna.');
      return false;
    }
    if (orderInfo.isForSomeoneElse) {
      if (!orderInfo.recipientInfo?.name || !orderInfo.recipientInfo?.phone) {
        setError('Inserisci nome e telefono del destinatario.');
        return false;
      }
      if (orderInfo.deliveryType === 'delivery' && !orderInfo.recipientInfo?.address) {
        setError('Inserisci l\'indirizzo del destinatario.');
        return false;
      }
    }
    return true;
  };

  const handleNext = () => {
    if (step === 'details') {
      if (validateDetails()) {
        setError(null);
        setStep('scheduling');
      }
    } else if (step === 'scheduling') {
      if (!orderInfo.scheduledTime) {
        setError('Seleziona un orario per il ritiro/consegna.');
        return false;
      }
      setError(null);
      setStep('payment');
    }
  };

  const handleOrder = async () => {
    if (!user) return;
    
    setIsSubmitting(true);
    setError(null);

    try {
      // 1. Update profile with latest info if needed
      if (!profile?.phone || !profile?.firstName) {
        await userService.updateProfile(user.uid, {
          firstName: orderInfo.firstName,
          lastName: orderInfo.lastName,
          phone: orderInfo.phone,
          address: orderInfo.address
        });
      }

      // 2. Prepare recipient info
      const finalOrderInfo = { ...orderInfo };
      if (!finalOrderInfo.isForSomeoneElse) {
          delete finalOrderInfo.recipientInfo;
      }

      // 3. Reserve Slot
      const today = new Date().toISOString().split('T')[0];
      await schedulingService.reserveSlot(
        today, 
        orderInfo.scheduledTime || "", 
        orderWeight,
        schedConfig?.maxOrdersPerSlot || 5
      );

      // 4. Create Order
      const { id: docId, orderNumber } = await orderService.createOrder(user.uid, cartItems, totalPrice, finalOrderInfo);
      
      // 5. Send Notification
      const notificationData = {
        order: { 
          ...finalOrderInfo,
          orderNumber: orderNumber, 
          totalPrice: totalPrice,
          paymentStatus: finalOrderInfo.paymentMethod === 'card' ? 'pending' : 'unpaid' 
        },
        items: cartItems.map(it => ({ 
          quantity: it.quantity, 
          productName: it.product.name 
        }))
      };

      try {
        await fetch('/api/notify-order', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(notificationData)
        });
      } catch (err) {
        console.error("Notification call failed:", err);
      }

      // 6. Handle Stripe if needed
      if (orderInfo.paymentMethod === 'card') {
        setStep('processing');
        
        const response = await fetch('/api/create-checkout-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            items: cartItems.map(item => ({
              name: item.product.name,
              price: item.finalPrice || item.product.price,
              quantity: item.quantity,
              description: item.product.description
            })),
            customerEmail: user.email,
            orderId: docId // Use internal Firestore ID for Stripe metadata
          })
        });

        const session = await response.json();
        
        if (session.error) {
          throw new Error(session.error);
        }

        // Redirect to Stripe
        window.location.href = session.url;
        return; // Redirecting...
      }

      // 6. Success for delivery/pickup without Stripe
      clearCart();
      onSuccess(orderNumber);
    } catch (err: any) {
      setError(err.message || "Errore durante la creazione dell'ordine.");
      setIsSubmitting(false);
      setStep('payment');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-brand-red text-white">
          <div className="flex items-center gap-3">
            <CreditCard className="h-6 w-6" />
            <h2 className="text-xl font-bebas tracking-wider uppercase">Conferma Ordine</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8">
          {/* Progress bar */}
          {step !== 'processing' && (
            <div className="flex items-center justify-center gap-4">
              <div className={`flex items-center gap-2 ${step === 'details' ? 'text-brand-red' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step === 'details' ? 'bg-brand-red text-white' : 'bg-gray-100'}`}>1</div>
                <span className="font-bold uppercase text-xs tracking-widest hidden sm:inline">Dettagli</span>
              </div>
              <div className="h-px w-8 bg-gray-200"></div>
              <div className={`flex items-center gap-2 ${step === 'scheduling' ? 'text-brand-red' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step === 'scheduling' ? 'bg-brand-red text-white' : 'bg-gray-100'}`}>2</div>
                <span className="font-bold uppercase text-xs tracking-widest hidden sm:inline">Orario</span>
              </div>
              <div className="h-px w-8 bg-gray-200"></div>
              <div className={`flex items-center gap-2 ${step === 'payment' ? 'text-brand-red' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step === 'payment' ? 'bg-brand-red text-white' : 'bg-gray-100'}`}>3</div>
                <span className="font-bold uppercase text-xs tracking-widest hidden sm:inline">Pagamento</span>
              </div>
            </div>
          )}

          <AnimatePresence mode="wait">
            {step === 'processing' ? (
              <motion.div
                key="processing"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center justify-center py-12 space-y-6"
              >
                <div className="relative w-20 h-20">
                  <div className="absolute inset-0 border-4 border-brand-red/20 rounded-full"></div>
                  <div className="absolute inset-0 border-4 border-brand-red border-t-transparent rounded-full animate-spin"></div>
                  <CreditCard className="absolute inset-0 m-auto h-8 w-8 text-brand-red" />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bebas text-brand-dark tracking-wide">Autorizzazione in corso...</h3>
                  <p className="text-sm text-gray-500">Stiamo elaborando il tuo pagamento in modo sicuro.</p>
                </div>
              </motion.div>
            ) : step === 'details' ? (
              <motion.div 
                key="details"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-6"
              >
                {/* ... existing details code ... */}
                <div className="space-y-4">
                  <h3 className="flex items-center gap-2 font-bebas text-lg tracking-wide text-brand-dark">
                    <User className="h-5 w-5 text-brand-red" /> I Tuoi Dati
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input 
                      type="text" 
                      placeholder="Nome"
                      value={orderInfo.firstName}
                      onChange={e => setOrderInfo({...orderInfo, firstName: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-red/20 focus:border-brand-red transition-all"
                    />
                    <input 
                      type="text" 
                      placeholder="Cognome"
                      value={orderInfo.lastName}
                      onChange={e => setOrderInfo({...orderInfo, lastName: e.target.value})}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-red/20 focus:border-brand-red transition-all"
                    />
                  </div>
                  <input 
                    type="tel" 
                    placeholder="Cellulare"
                    value={orderInfo.phone}
                    onChange={e => setOrderInfo({...orderInfo, phone: e.target.value})}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-red/20 focus:border-brand-red transition-all"
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="flex items-center gap-2 font-bebas text-lg tracking-wide text-brand-dark">
                    <Truck className="h-5 w-5 text-brand-red" /> Tipo Consegna
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      onClick={() => setOrderInfo({...orderInfo, deliveryType: 'delivery'})}
                      className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${
                        orderInfo.deliveryType === 'delivery' ? 'border-brand-red bg-brand-red/5' : 'border-gray-100 bg-gray-50 text-gray-400'
                      }`}
                    >
                      <Truck className="h-6 w-6" />
                      <span className="font-bold text-sm uppercase">Domicilio</span>
                    </button>
                    <button
                      onClick={() => setOrderInfo({...orderInfo, deliveryType: 'pickup'})}
                      className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${
                        orderInfo.deliveryType === 'pickup' ? 'border-brand-red bg-brand-red/5' : 'border-gray-100 bg-gray-50 text-gray-400'
                      }`}
                    >
                      <Store className="h-6 w-6" />
                      <span className="font-bold text-sm uppercase">Ritiro</span>
                    </button>
                  </div>

                  {orderInfo.deliveryType === 'delivery' && (
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-gray-400 ml-1">Indirizzo di Consegna</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <input 
                          type="text" 
                          placeholder="Via, Civico, Città"
                          value={orderInfo.address}
                          onChange={e => setOrderInfo({...orderInfo, address: e.target.value})}
                          className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-red/20 focus:border-brand-red transition-all"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                  <button 
                    onClick={() => setOrderInfo({...orderInfo, isForSomeoneElse: !orderInfo.isForSomeoneElse})}
                    className="flex items-center gap-2 text-sm font-bold text-gray-600 hover:text-brand-red transition-colors"
                  >
                    <Gift className={`h-5 w-5 ${orderInfo.isForSomeoneElse ? 'text-brand-red' : 'text-gray-400'}`} />
                    Ordina per qualcun altro?
                  </button>

                  <AnimatePresence>
                    {orderInfo.isForSomeoneElse && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden space-y-4 mt-4 bg-white p-4 rounded-xl shadow-inner"
                      >
                        <input 
                          type="text" 
                          placeholder="Nome Destinatario"
                          value={orderInfo.recipientInfo?.name}
                          onChange={e => setOrderInfo({...orderInfo, recipientInfo: {...orderInfo.recipientInfo!, name: e.target.value}})}
                          className="w-full px-4 py-2 border border-gray-100 rounded-lg outline-none focus:border-brand-red"
                        />
                        <input 
                          type="tel" 
                          placeholder="Telefono Destinatario"
                          value={orderInfo.recipientInfo?.phone}
                          onChange={e => setOrderInfo({...orderInfo, recipientInfo: {...orderInfo.recipientInfo!, phone: e.target.value}})}
                          className="w-full px-4 py-2 border border-gray-100 rounded-lg outline-none focus:border-brand-red"
                        />
                        {orderInfo.deliveryType === 'delivery' && (
                          <input 
                            type="text" 
                            placeholder="Indirizzo Destinatario"
                            value={orderInfo.recipientInfo?.address}
                            onChange={e => setOrderInfo({...orderInfo, recipientInfo: {...orderInfo.recipientInfo!, address: e.target.value}})}
                            className="w-full px-4 py-2 border border-gray-100 rounded-lg outline-none focus:border-brand-red"
                          />
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            ) : step === 'scheduling' ? (
              <motion.div 
                key="scheduling"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="bg-brand-red/5 p-4 rounded-2xl border border-brand-red/10 flex gap-4 items-center">
                  <div className="p-3 bg-brand-red text-white rounded-xl shadow-md">
                    <Clock className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-bebas text-brand-dark tracking-wide">Tempo di Preparazione Stimato</h4>
                    <p className="text-sm text-brand-red font-bold">Circa {estimatedPrepTime} minuti</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="flex items-center gap-2 font-bebas text-lg tracking-wide text-brand-dark">
                    <Calendar className="h-5 w-5 text-brand-red" /> Seleziona Orario per {orderInfo.deliveryType === 'pickup' ? 'il Ritiro' : 'la Consegna'}
                  </h3>
                  
                  <div className="space-y-6">
                    {Object.entries(groupedSlots).sort(([a], [b]) => a.localeCompare(b)).map(([hour, slots]) => (
                      <div key={hour} className="space-y-3">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bebas text-brand-red tracking-wide">Ore {hour}:00</span>
                          <div className="h-px flex-1 bg-gray-100"></div>
                        </div>
                        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
                          {slots.map(slot => (
                            <div key={slot.time} className="flex flex-col gap-1">
                              <button
                                disabled={!slot.isAvailable}
                                onClick={() => setOrderInfo({...orderInfo, scheduledTime: slot.time})}
                                className={`w-full py-2 px-1 rounded-xl text-xs font-bold transition-all border-2 ${
                                  orderInfo.scheduledTime === slot.time 
                                    ? 'bg-brand-red text-white border-brand-red shadow-lg shadow-brand-red/20 scale-105' 
                                    : !slot.isAvailable
                                      ? 'bg-gray-100 text-gray-300 border-gray-100 cursor-not-allowed'
                                      : 'bg-gray-50 text-gray-500 border-gray-100 hover:border-gray-200'
                                }`}
                              >
                                {slot.time}
                              </button>
                              {!slot.isAvailable && slot.occupancy >= slot.maxCapacity && (
                                <span className="text-[8px] text-center text-red-400 font-bold uppercase">Occupato</span>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                    
                    {timeSlots.length === 0 && (
                      <div className="p-8 text-center bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                        <AlertCircle className="h-8 w-8 text-gray-300 mx-auto mb-3" />
                        <p className="text-sm text-gray-500 font-bold">Nessun orario disponibile per oggi.</p>
                        <p className="text-xs text-gray-400 mt-1">Siamo probabilmente vicini all'orario di chiusura.</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex gap-3">
                  <AlertCircle className="h-5 w-5 text-blue-600 shrink-0" />
                  <p className="text-xs text-blue-800 leading-tight">
                    L'orario selezionato è indicativo. Faremo il possibile per rispettarlo, ma potrebbe variare leggermente in base alla complessità dell'ordine e al carico di lavoro.
                  </p>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="payment"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {/* Summary card before payment */}
                <div className="bg-gray-50 p-4 rounded-2xl border border-gray-200 flex justify-between items-center text-sm">
                  <div className="flex items-center gap-2 font-bold text-gray-600">
                    <Clock className="h-4 w-4 text-brand-red" />
                    <span>{orderInfo.scheduledTime}</span>
                    <span className="text-gray-300">|</span>
                    <Truck className="h-4 w-4 text-brand-red" />
                    <span className="capitalize">{orderInfo.deliveryType}</span>
                  </div>
                  <button 
                    onClick={() => setStep('scheduling')}
                    className="text-brand-red font-bold hover:underline"
                  >
                    Modifica
                  </button>
                </div>

                <div className="space-y-4">
                  <h3 className="flex items-center gap-2 font-bebas text-lg tracking-wide text-brand-dark">
                    <CreditCard className="h-5 w-5 text-brand-red" /> Metodo di Pagamento
                  </h3>
                  <div className="space-y-3">
                    <button
                      onClick={() => setOrderInfo({...orderInfo, paymentMethod: 'delivery'})}
                      className={`w-full p-4 rounded-2xl border-2 text-left transition-all flex items-center gap-4 ${
                        orderInfo.paymentMethod === 'delivery' ? 'border-brand-red bg-brand-red/5' : 'border-gray-100 bg-gray-50 text-gray-400'
                      }`}
                    >
                      <div className={`p-2 rounded-full ${orderInfo.paymentMethod === 'delivery' ? 'bg-brand-red text-white' : 'bg-gray-200'}`}>
                        <Truck className="h-5 w-5" />
                      </div>
                      <div>
                        <p className={`font-bold text-sm uppercase ${orderInfo.paymentMethod === 'delivery' ? 'text-brand-dark' : ''}`}>Solo Ordine (Paga alla Consegna)</p>
                        <p className="text-xs">Contanti o POS al momento della ricezione</p>
                      </div>
                    </button>

                    <button
                      onClick={() => setOrderInfo({...orderInfo, paymentMethod: 'card'})}
                      className={`w-full p-4 rounded-2xl border-2 text-left transition-all flex items-center gap-4 ${
                        orderInfo.paymentMethod === 'card' ? 'border-brand-red bg-brand-red/5' : 'border-gray-100 bg-gray-50 text-gray-400'
                      }`}
                    >
                      <div className={`p-2 rounded-full ${orderInfo.paymentMethod === 'card' ? 'bg-brand-red text-white' : 'bg-gray-200'}`}>
                        <CreditCard className="h-5 w-5" />
                      </div>
                      <div>
                        <p className={`font-bold text-sm uppercase ${orderInfo.paymentMethod === 'card' ? 'text-brand-dark' : ''}`}>Ordina e Paga Ora (Online)</p>
                        <p className="text-xs">Semplice, veloce e senza contanti</p>
                      </div>
                    </button>
                  </div>
                </div>

                {orderInfo.paymentMethod === 'card' && (
                  <div className="p-6 bg-brand-dark text-white rounded-2xl space-y-4 shadow-xl text-center">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Pagamento Sicuro</span>
                      <div className="flex gap-1">
                        <Lock className="h-4 w-4 text-white/40" />
                      </div>
                    </div>
                    <div className="py-4 space-y-3">
                      <div className="flex justify-center">
                        <div className="p-3 bg-white/10 rounded-full">
                          <CreditCard className="h-8 w-8 text-brand-red" />
                        </div>
                      </div>
                      <h4 className="text-xl font-bebas tracking-wide">Sarai reindirizzato a Stripe</h4>
                      <p className="text-xs text-white/60">
                        Per la tua sicurezza, i dati della carta vengono gestiti direttamente sui server certificati di Stripe.
                      </p>
                    </div>
                  </div>
                )}

                <div className="p-4 bg-yellow-50 rounded-2xl border border-yellow-100 flex gap-3">
                  <AlertCircle className="h-5 w-5 text-yellow-600 shrink-0" />
                  <p className="text-xs text-yellow-800 leading-tight">
                    Facendo clic su "Conferma Ordine", accetti i termini di servizio. {orderInfo.paymentMethod === 'card' ? 'L\'addebito avverrà dopo la conferma.' : 'Il pagamento verrà effettuato al momento della ricezione.'}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {error && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-red-50 text-red-600 rounded-2xl border border-red-100 text-sm font-medium flex items-center gap-2"
            >
              <AlertCircle className="h-5 w-5" />
              {error}
            </motion.div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-100 bg-gray-50 flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <span className="text-gray-500 font-bold uppercase text-xs tracking-widest">Totale Ordine</span>
            <span className="text-2xl font-bebas text-brand-red tracking-wider">€{totalPrice.toFixed(2)}</span>
          </div>
          
          <div className="flex gap-3">
            {step !== 'details' && (
              <button
                onClick={() => {
                  if (step === 'scheduling') setStep('details');
                  else if (step === 'payment') setStep('scheduling');
                }}
                className="flex-1 py-4 px-6 border-2 border-gray-200 text-gray-500 font-bold rounded-2xl hover:bg-white transition-all flex items-center justify-center gap-2 uppercase text-xs tracking-widest"
              >
                <ChevronLeft className="h-4 w-4" /> Indietro
              </button>
            )}
            <button
              onClick={step === 'payment' ? handleOrder : handleNext}
              disabled={isSubmitting}
              className="flex-[2] py-4 px-6 bg-brand-red text-white font-bold rounded-2xl hover:bg-brand-red/90 transition-all flex items-center justify-center gap-2 shadow-lg shadow-brand-red/20 active:scale-95 disabled:opacity-50 uppercase text-xs tracking-widest"
            >
              {isSubmitting ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  {step === 'payment' ? 'Conferma Ordine' : 'Continua'}
                  {step !== 'payment' && <ChevronRight className="h-4 w-4" />}
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default CheckoutModal;
