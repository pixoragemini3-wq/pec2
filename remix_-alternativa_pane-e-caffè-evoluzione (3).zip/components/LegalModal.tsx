import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Shield, FileText } from 'lucide-react';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'privacy' | 'terms';
}

const LegalModal: React.FC<LegalModalProps> = ({ isOpen, onClose, type }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 md:p-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-brand-dark/40 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-brand-cream w-full max-w-2xl max-h-[85vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col border border-brand-red/10"
          >
            {/* Header */}
            <div className={`p-6 border-b flex items-center justify-between sticky top-0 bg-brand-cream/95 backdrop-blur-md z-10 ${
              type === 'privacy' ? 'border-blue-100' : 'border-orange-100'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  type === 'privacy' ? 'bg-blue-50 text-blue-600' : 'bg-orange-50 text-orange-600'
                }`}>
                  {type === 'privacy' ? <Shield size={24} /> : <FileText size={24} />}
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bebas tracking-wide text-brand-dark">
                    {type === 'privacy' ? 'Privacy Policy' : 'Termini e Condizioni'}
                  </h3>
                  <p className="text-[10px] uppercase font-bold text-gray-400 tracking-widest leading-none">
                    Pane & Caffè - Ultimo aggiornamento: Maggio 2026
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                aria-label="Chiudi"
              >
                <X size={24} className="text-gray-400" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6 text-brand-dark/80 scrollbar-thin">
              {type === 'privacy' ? (
                <>
                  <section>
                    <h4 className="font-bebas text-lg text-brand-red tracking-wide mb-2 uppercase">1. Raccolta Dati</h4>
                    <p className="text-sm leading-relaxed">
                      Raccogliamo solo i dati strettamente necessari per la gestione dei tuoi ordini: nome, cognome, indirizzo email, numero di telefono e indirizzo di consegna. Utilizziamo il login tramite Google per semplificare l'accesso e non memorizziamo mai le tue password.
                    </p>
                  </section>
                  <section>
                    <h4 className="font-bebas text-lg text-brand-red tracking-wide mb-2 uppercase">2. Utilizzo delle Informazioni</h4>
                    <p className="text-sm leading-relaxed">
                      I tuoi dati vengono utilizzati esclusivamente per elaborare gli ordini, contattarti in caso di problemi con la consegna e permetterti di visualizzare lo storico dei tuoi acquisti. Non vendiamo né condividiamo i tuoi dati con terze parti per scopi pubblicitari.
                    </p>
                  </section>
                  <section>
                    <h4 className="font-bebas text-lg text-brand-red tracking-wide mb-2 uppercase">3. Sicurezza</h4>
                    <p className="text-sm leading-relaxed">
                      Adottiamo misure di sicurezza avanzate tramite l'infrastruttura di Google Firebase per proteggere le tue informazioni da accessi non autorizzati. I pagamenti online sono gestiti tramite provider certificati e sicuri.
                    </p>
                  </section>
                  <section>
                    <h4 className="font-bebas text-lg text-brand-red tracking-wide mb-2 uppercase">4. I tuoi Diritti</h4>
                    <p className="text-sm leading-relaxed">
                      Puoi richiedere in qualsiasi momento la cancellazione del tuo account e di tutti i dati associati contattandoci direttamente tramite i nostri canali social o via email.
                    </p>
                  </section>
                </>
              ) : (
                <>
                  <section>
                    <h4 className="font-bebas text-lg text-brand-red tracking-wide mb-2 uppercase">1. Ordini e Prodotti</h4>
                    <p className="text-sm leading-relaxed">
                      Gli ordini effettuati tramite questa piattaforma sono soggetti a disponibilità. Pane & Caffè si riserva il diritto di annullare ordini in caso di esaurimento scorte o problemi tecnici, informando tempestivamente il cliente.
                    </p>
                  </section>
                  <section>
                    <h4 className="font-bebas text-lg text-brand-red tracking-wide mb-2 uppercase">2. Consegna e Orari</h4>
                    <p className="text-sm leading-relaxed">
                      Garantiamo il massimo impegno nel rispettare l'orario di consegna selezionato. Eventuali ritardi dovuti a traffico o picchi di lavoro non potranno essere imputati come inadempienza. Ricordiamo che il lunedì la nostra attività è chiusa e non si accettano ordini.
                    </p>
                  </section>
                  <section>
                    <h4 className="font-bebas text-lg text-brand-red tracking-wide mb-2 uppercase">3. Cancellazione Ordini</h4>
                    <p className="text-sm leading-relaxed">
                      È possibile cancellare un ordine finché lo stato non è "In Preparazione" o "Confermato". Una volta iniziata la lavorazione, l'ordine è considerato definitivo e non rimborsabile.
                    </p>
                  </section>
                  <section>
                    <h4 className="font-bebas text-lg text-brand-red tracking-wide mb-2 uppercase">4. Prezzi e Pagamenti</h4>
                    <p className="text-sm leading-relaxed">
                      Tutti i prezzi sono espressi in Euro e comprensivi di IVA. Il pagamento può essere effettuato online tramite carta o contanti/POS alla consegna. In caso di pagamento alla consegna, il cliente si impegna a saldare l'importo totale al momento del ritiro dei prodotti.
                    </p>
                  </section>
                </>
              )}
            </div>

            {/* Footer */}
            <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-end">
              <button
                onClick={onClose}
                className="px-8 py-3 bg-brand-red text-white font-bebas tracking-widest text-xl rounded-xl hover:bg-brand-red/90 transition-colors shadow-lg active:scale-95"
              >
                Ho Letto e Accetto
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default LegalModal;
