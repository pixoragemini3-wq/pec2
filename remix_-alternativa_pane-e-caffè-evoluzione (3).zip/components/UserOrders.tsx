import React, { useEffect, useState } from 'react';
import { db } from '../lib/firebase';
import { collection, getDocs } from 'firebase/firestore';
import { Order, OrderItem } from '../types';
import { useAuth } from '../context/auth-context';
import { orderService } from '../services/orderService';
import { motion, AnimatePresence } from 'motion/react';
import { Package, Truck, CheckCircle, Clock, XCircle, Calendar } from 'lucide-react';
const UserOrders: React.FC = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (!user) return;

    const unsubscribe = orderService.subscribeToUserOrders(user.uid, (ordersData) => {
      setOrders(ordersData);
    });

    return () => unsubscribe();
  }, [user]);

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'pending': return { icon: <Clock className="h-4 w-4" />, label: 'In attesa', classes: 'bg-yellow-50 text-yellow-600 border-yellow-100' };
      case 'confirmed': return { icon: <CheckCircle className="h-4 w-4" />, label: 'Confermato', classes: 'bg-blue-50 text-blue-600 border-blue-100' };
      case 'delivering': return { icon: <Truck className="h-4 w-4" />, label: 'In consegna', classes: 'bg-purple-50 text-purple-600 border-purple-100' };
      case 'completed': return { icon: <CheckCircle className="h-4 w-4" />, label: 'Completato', classes: 'bg-green-50 text-green-600 border-green-100' };
      case 'cancelled': return { icon: <XCircle className="h-4 w-4" />, label: 'Annullato', classes: 'bg-red-50 text-red-600 border-red-100' };
      default: return { icon: <Clock className="h-4 w-4" />, label: status, classes: 'bg-gray-50 text-gray-600 border-gray-100' };
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    if (window.confirm('Sei sicuro di voler annullare questo ordine?')) {
      try {
        await orderService.cancelOrder(orderId);
        // FeedBack is handled by onSnapshot, but let's make it clear
      } catch (error: any) {
        console.error("Error cancelling order:", error);
        alert(`Errore: ${error.message || "Non è stato possibile annullare l'ordine."}`);
      }
    }
  };

  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [orderItems, setOrderItems] = useState<Record<string, OrderItem[]>>({});
  const [loadingItems, setLoadingItems] = useState<string | null>(null);

  const toggleOrderDetails = async (orderId: string) => {
    if (expandedOrderId === orderId) {
      setExpandedOrderId(null);
      return;
    }

    setExpandedOrderId(orderId);

    if (!orderItems[orderId]) {
      setLoadingItems(orderId);
      try {
        const itemsSnapshot = await getDocs(collection(db, `orders/${orderId}/items`));
        const items = itemsSnapshot.docs.map(doc => ({
          id: doc.id,
          orderId,
          ...doc.data()
        })) as OrderItem[];
        setOrderItems(prev => ({ ...prev, [orderId]: items }));
      } catch (error) {
        console.error("Error fetching items:", error);
      } finally {
        setLoadingItems(null);
      }
    }
  };

  const getGoogleCalendarUrl = (order: Order) => {
    const title = `Ordine Pane & Caffè: ${order.orderNumber}`;
    const date = order.createdAt ? (order.createdAt.toDate ? order.createdAt.toDate() : new Date(order.createdAt)) : new Date();
    
    // Create start and end time based on scheduledTime (format HH:mm)
    let startTime = new Date(date);
    if (order.scheduledTime) {
      const [hours, minutes] = order.scheduledTime.split(':').map(Number);
      startTime.setHours(hours, minutes, 0, 0);
    }
    
    const endTime = new Date(startTime.getTime() + 30 * 60000); // 30 mins duration
    
    const formatStr = (d: Date) => d.toISOString().replace(/-|:|\.\d\d\d/g, "");
    const dates = `${formatStr(startTime)}/${formatStr(endTime)}`;
    
    const details = `Dettaglio ordine: ${order.totalPrice.toFixed(2)}€\nTipo: ${order.deliveryType === 'delivery' ? 'Consegna' : 'Ritiro'}`;
    const location = "Pane & Caffè, Ariano Irpino, AV, Italia";

    return `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${dates}&details=${encodeURIComponent(details)}&location=${encodeURIComponent(location)}`;
  };

  return (
    <div className="space-y-4">
      {orders.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-gray-200">
          <Package className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 font-medium">Non hai ancora effettuato ordini.</p>
        </div>
      ) : (
        orders.map((order) => {
          const statusConfig = getStatusConfig(order.status);
          
          return (
            <motion.div 
              key={order.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl shadow-sm p-4 md:p-6 border border-gray-100 overflow-hidden"
            >
              <div className="flex flex-wrap justify-between items-start gap-4 mb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-brand-dark uppercase tracking-wider">Ordine {order.orderNumber || `#${order.id.slice(-6)}`}</span>
                    <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[10px] font-bold uppercase ${statusConfig.classes}`}>
                      {statusConfig.icon}
                      {statusConfig.label}
                    </div>
                  </div>
                  <p className="text-xs text-gray-400">
                    {order.createdAt ? (order.createdAt.toDate ? order.createdAt.toDate().toLocaleString() : new Date(order.createdAt).toLocaleString()) : 'Recentissimo'}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bebas text-brand-red tracking-wide">€{Number(order.totalPrice || 0).toFixed(2)}</p>
                  <div className="flex items-center justify-end gap-1 text-[10px] uppercase font-bold text-gray-400">
                    {order.paymentStatus === 'paid' ? (
                      <span className="text-green-600 flex items-center gap-1"><CheckCircle className="h-3 w-3" /> Pagato Online</span>
                    ) : (
                      <span className="text-yellow-600 flex items-center gap-1"><Clock className="h-3 w-3" /> Da Pagare</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-3 mb-4 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-500 font-medium">Orario {order.deliveryType === 'pickup' ? 'Ritiro' : 'Consegna'}:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-brand-red text-sm flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {order.scheduledTime}
                    </span>
                    <a 
                      href={getGoogleCalendarUrl(order)} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="p-1.5 bg-white rounded-lg border border-gray-200 text-gray-500 hover:text-brand-red hover:border-brand-red transition-all flex items-center gap-1 group"
                      title="Aggiungi a Google Calendar"
                    >
                      <Calendar className="h-3 w-3" />
                      <span className="text-[10px] font-bold uppercase tracking-tighter">Google Cal</span>
                    </a>
                  </div>
                </div>
                <div className="h-px bg-gray-100/50 w-full"></div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-500">Tipo:</span>
                  <span className="font-bold text-brand-dark uppercase">{order.deliveryType === 'delivery' ? 'Consegna a domicilio' : 'Ritiro in sede'}</span>
                </div>
                {order.deliveryType === 'delivery' && (
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-500">Indirizzo:</span>
                    <span className="font-medium text-brand-dark text-right truncate ml-4">
                      {order.isForSomeoneElse ? order.recipientInfo?.address : order.customerInfo?.address}
                    </span>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <button 
                  className="text-brand-red text-xs font-bold uppercase tracking-wider hover:underline flex items-center gap-1"
                  onClick={() => toggleOrderDetails(order.id)}
                >
                  {expandedOrderId === order.id ? 'Nascondi Dettagli' : 'Dettagli Prodotti'}
                  <Package className="h-3 w-3" />
                </button>
                
                {(order.status === 'pending' || order.status === 'confirmed') && (
                  <button 
                    onClick={() => handleCancelOrder(order.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-[10px] font-bold uppercase border border-red-100 hover:bg-white hover:border-red-500 transition-all font-bebas tracking-wider"
                  >
                    <XCircle className="h-3 w-3" />
                    Annulla Ordine
                  </button>
                )}
              </div>

              <AnimatePresence>
                {expandedOrderId === order.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="pt-4 mt-4 border-t border-gray-100 space-y-3">
                      {loadingItems === order.id ? (
                        <p className="text-center text-xs text-gray-400 py-4 italic">Caricamento articoli...</p>
                      ) : (
                        orderItems[order.id]?.map((item) => (
                          <div key={item.id} className="flex justify-between text-xs">
                            <div className="flex-grow">
                              <p className="font-bold text-brand-dark">
                                {item.quantity}x {item.productName}
                                <span className="ml-2 text-[8px] font-bold uppercase p-0.5 bg-gray-100 rounded text-gray-500">
                                  {item.configuration.variant}
                                </span>
                              </p>
                              <div className="text-[10px] space-y-0.5 mt-0.5">
                                {item.configuration.removedIngredients.length > 0 && (
                                  <p className="text-red-400">Senza: {item.configuration.removedIngredients.join(', ')}</p>
                                )}
                                {item.configuration.addedExtras.length > 0 && (
                                  <p className="text-green-500">Extra: {item.configuration.addedExtras.map(e => e.name).join(', ')}</p>
                                )}
                                {item.configuration.notes && (
                                  <p className="italic text-gray-500">"{item.configuration.notes}"</p>
                                )}
                              </div>
                            </div>
                            <span className="font-bebas text-brand-red text-sm">€{(item.priceAtPurchase * item.quantity).toFixed(2)}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })
      )}
    </div>
  );
};

export default UserOrders;
