import React from 'react';
import { RESTAURANT_ADDRESS } from '../constants';

interface FooterProps {
  onOpenLegal: (type: 'privacy' | 'terms') => void;
}

const Footer: React.FC<FooterProps> = ({ onOpenLegal }) => {
  return (
    <footer className="bg-brand-red/5 border-t border-brand-red/10">
      <div className="container mx-auto px-4 py-8 text-center text-gray-600">
        <div className="mb-4">
            <p className="font-bold text-lg text-brand-dark">Pane & Caffè</p>
            <p><a href="https://www.panecaffe.info/" target="_blank" rel="noopener noreferrer" className="text-brand-red hover:underline">Sito Ufficiale</a></p>
            <p>{RESTAURANT_ADDRESS.replace(', ', '\n')}</p>
            <p>WhatsApp: +39 0825 172 8034 | Email: pane.caffebonito@gmail.com</p>
        </div>
        <div className="flex justify-center gap-6 mb-4 text-sm font-medium">
            <button 
              onClick={() => onOpenLegal('privacy')}
              className="hover:text-brand-red transition-colors"
            >
              Privacy Policy
            </button>
            <button 
              onClick={() => onOpenLegal('terms')}
              className="hover:text-brand-red transition-colors"
            >
              Termini e Condizioni
            </button>
        </div>
        <div className="border-t border-brand-red/10 pt-4 mt-4">
            <p>&copy; {new Date().getFullYear()} Pane & Caffè. Tutti i diritti riservati.</p>
            <p className="text-sm mt-2">Sviluppato da <a href="https://bit.ly/4bfxN3d" target="_blank" rel="noopener noreferrer" className="hover:text-brand-red transition-colors">VinCam</a></p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;