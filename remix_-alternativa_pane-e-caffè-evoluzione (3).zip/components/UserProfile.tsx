import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/auth-context';
import { userService, UserProfile as UserProfileType } from '../services/userService';
import { motion } from 'motion/react';
import { User, Phone, MapPin, Save, AlertCircle, CheckCircle } from 'lucide-react';

interface UserProfileComponentProps {
  onUpdateSuccess?: () => void;
}

const UserProfileComponent: React.FC<UserProfileComponentProps> = ({ onUpdateSuccess }) => {
  const { user, profile } = useAuth();
  const [formData, setFormData] = useState<Partial<UserProfileType>>({
    firstName: '',
    lastName: '',
    phone: '',
    address: ''
  });
  const [isSaving, setIsSaving] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);

  useEffect(() => {
    if (profile) {
      setFormData({
        firstName: profile.firstName || '',
        lastName: profile.lastName || '',
        phone: profile.phone || '',
        address: profile.address || ''
      });
    }
  }, [profile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsSaving(true);
    setStatus(null);

    try {
      if (!formData.firstName || !formData.lastName || !formData.phone) {
        throw new Error('Nome, Cognome e Telefono sono obbligatori');
      }

      await userService.updateProfile(user.uid, formData);
      setStatus({ type: 'success', message: 'Profilo aggiornato con successo!' });
      if (onUpdateSuccess) onUpdateSuccess();
    } catch (error: any) {
      setStatus({ type: 'error', message: error.message || 'Errore durante l\'aggiornamento' });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-brand-red/10 rounded-lg">
            <User className="h-5 w-5 text-brand-red" />
          </div>
          <h3 className="text-xl font-bold text-brand-dark">Il Mio Profilo</h3>
        </div>
        {profile?.userCode && (
          <div className="px-3 py-1 bg-brand-red text-white text-xs font-bold rounded-full tracking-widest shadow-sm">
            {profile.userCode}
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-bold uppercase text-gray-500 ml-1">Nome</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input 
                type="text"
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-red/20 focus:border-brand-red outline-none transition-all"
                placeholder="Mario"
                required
              />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold uppercase text-gray-500 ml-1">Cognome</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input 
                type="text"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-red/20 focus:border-brand-red outline-none transition-all"
                placeholder="Rossi"
                required
              />
            </div>
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-bold uppercase text-gray-500 ml-1">Telefono</label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input 
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-red/20 focus:border-brand-red outline-none transition-all"
              placeholder="+39 3XX XXXXXXX"
              required
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-bold uppercase text-gray-500 ml-1">Indirizzo di Consegna (Opzionale)</label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input 
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-red/20 focus:border-brand-red outline-none transition-all"
              placeholder="Via Roma, 12, Ariano Irpino"
            />
          </div>
        </div>

        {status && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-3 rounded-xl flex items-center gap-2 ${status.type === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100'}`}
          >
            {status.type === 'success' ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
            <span className="text-sm font-medium">{status.message}</span>
          </motion.div>
        )}

        <button
          type="submit"
          disabled={isSaving}
          className="w-full bg-brand-red text-white font-bold py-3 px-6 rounded-xl hover:bg-brand-red/90 transition-all flex items-center justify-center gap-2 shadow-lg shadow-brand-red/20 disabled:opacity-50"
        >
          {isSaving ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <>
              <Save className="h-5 w-5" />
              Salva Modifiche
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default UserProfileComponent;
