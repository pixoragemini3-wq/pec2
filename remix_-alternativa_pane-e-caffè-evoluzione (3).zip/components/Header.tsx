import React from 'react';
import Logo from './Logo';
import ShoppingCartIcon from './icons/ShoppingCartIcon';
import { User as UserIcon, ShieldCheck, RefreshCw } from 'lucide-react';
import { useAuth } from '../context/auth-context';
import { authService } from '../services/authService';

interface HeaderProps {
  cartItemCount: number;
  onCartClick: () => void;
  onScrollToTop: () => void;
  onAdminClick: () => void;
  onUserClick: () => void;
  isCartAnimating?: boolean;
}

const Header: React.FC<HeaderProps> = ({ cartItemCount, onCartClick, onScrollToTop, onAdminClick, onUserClick, isCartAnimating }) => {
  const { user, profile } = useAuth();

  const handleUserAction = async () => {
    if (user) {
      onUserClick();
      return;
    }
    
    try {
      await authService.signInWithGoogle();
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user') {
        return;
      }
      alert('Errore durante l\'accesso con Google');
    }
  };
  
  return (
    <header className="bg-brand-cream/90 backdrop-blur-sm sticky top-0 z-40 shadow-sm border-b border-brand-red/10 pt-[env(safe-area-inset-top)]">
      <div className="container mx-auto px-4 h-[80px] md:h-[110px] flex justify-between items-center">
        <div className="flex items-center">
          <button onClick={onScrollToTop} className="group" aria-label="Torna in cima">
            <Logo className="h-[58px] md:h-[85px] w-auto"/>
          </button>
        </div>
        
        <div className="flex items-center gap-4">
          {profile?.isAdmin && (
            <button 
              className="group flex flex-col items-center gap-1 p-2 rounded-full hover:bg-brand-red/10 transition-all relative"
              onClick={onAdminClick}
              title="Pannello di Controllo Admin"
            >
              <div className="bg-brand-red p-1.5 rounded-lg shadow-sm group-hover:scale-110 transition-transform">
                <ShieldCheck className="h-5 w-5 md:h-6 md:w-6 text-white" />
              </div>
              <span className="text-[10px] uppercase font-black text-brand-red hidden md:block tracking-wider">
                ADMIN
              </span>
              <div className="absolute top-0 right-0 h-2 w-2 bg-brand-red rounded-full animate-ping"></div>
            </button>
          )}

          <button 
            className="text-brand-dark hover:text-brand-red transition-colors p-2 rounded-full hover:bg-brand-red/5 flex flex-col items-center gap-1 group relative"
            onClick={handleUserAction}
          >
            {user?.photoURL ? (
              <img src={user.photoURL} alt="User" className="h-6 w-6 md:h-8 md:w-8 rounded-full border border-brand-red/20 outline outline-2 outline-transparent group-hover:outline-brand-red/20 transition-all" />
            ) : (
              <UserIcon className="h-6 w-6 md:h-8 md:w-8" />
            )}
            <span className="text-[10px] uppercase font-bold hidden md:block">
              {user ? (profile?.firstName || 'Utente') : 'Accedi'}
            </span>
            {user && (
              <div className="absolute -top-1 -right-1 h-3 w-3 bg-green-500 border-2 border-white rounded-full"></div>
            )}
          </button>

          <button
            onClick={onCartClick}
            className={`relative text-brand-dark hover:text-brand-red transition-colors duration-300 p-2 rounded-full hover:bg-brand-red/5 ${isCartAnimating ? 'animate-cart-jiggle-once' : ''}`}
            aria-label="Apri carrello"
          >
            <ShoppingCartIcon className="h-[32px] w-[32px] md:h-[45px] w-[45px]" />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-brand-red text-white text-[10px] md:text-xs font-bold rounded-full h-[20px] w-[20px] md:h-[28px] w-[28px] flex items-center justify-center animate-pulse">
                {cartItemCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

export default React.memo(Header);