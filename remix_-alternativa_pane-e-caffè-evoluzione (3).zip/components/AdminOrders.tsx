import React, { useEffect, useState } from 'react';
import { db } from '../lib/firebase';
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot,
  doc,
  getDocs
} from 'firebase/firestore';
import { Order, OrderItem } from '../types';
import { orderService } from '../services/orderService';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Package, 
  Truck, 
  CheckCircle, 
  Clock, 
  XCircle, 
  CreditCard,
  User,
  MapPin,
  Phone
} from 'lucide-react';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';
import * as XLSX from 'xlsx';

const AdminOrders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [viewMode, setViewMode] = useState<'cards' | 'grid'>('cards');
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [loadingItems, setLoadingItems] = useState(false);

  const [orderItemsMap, setOrderItemsMap] = useState<Record<string, OrderItem[]>>({});
  const [fetchingAllItems, setFetchingAllItems] = useState(false);

  useEffect(() => {
    const q = query(
      collection(db, 'orders'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Order[];
      setOrders(ordersData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'orders');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Fetch all items for all orders when viewMode is 'grid'
  useEffect(() => {
    if (viewMode === 'grid' && orders.length > 0) {
      fetchAllOrderItems();
    }
  }, [viewMode, orders.length]);

  const fetchAllOrderItems = async () => {
    const ordersToFetch = orders.filter(o => !orderItemsMap[o.id]);
    if (ordersToFetch.length === 0) return;

    setFetchingAllItems(true);
    try {
      // Fetch in parallel but could be many, so we map them
      const fetchPromises = ordersToFetch.map(async (order) => {
        const itemsSnapshot = await getDocs(collection(db, `orders/${order.id}/items`));
        return {
          orderId: order.id,
          items: itemsSnapshot.docs.map(doc => ({
            id: doc.id,
            orderId: order.id,
            ...doc.data()
          })) as OrderItem[]
        };
      });

      const results = await Promise.all(fetchPromises);
      const newItemsMap = { ...orderItemsMap };
      results.forEach(res => {
        newItemsMap[res.orderId] = res.items;
      });
      setOrderItemsMap(newItemsMap);
    } catch (err) {
      console.error("Error fetching all items:", err);
    } finally {
      setFetchingAllItems(false);
    }
  };

  const fetchOrderItems = async (orderId: string) => {
    if (orderItemsMap[orderId]) {
      setOrderItems(orderItemsMap[orderId]);
      return;
    }
    
    setLoadingItems(true);
    try {
      const itemsSnapshot = await getDocs(collection(db, `orders/${orderId}/items`));
      const items = itemsSnapshot.docs.map(doc => ({
        id: doc.id,
        orderId,
        ...doc.data()
      })) as OrderItem[];
      setOrderItems(items);
      setOrderItemsMap(prev => ({ ...prev, [orderId]: items }));
    } catch (error) {
      console.error("Error fetching items:", error);
    } finally {
      setLoadingItems(false);
    }
  };

  const handleOrderClick = (order: Order) => {
    setSelectedOrder(order);
    fetchOrderItems(order.id);
  };

  const updateStatus = async (orderId: string, status: Order['status']) => {
    try {
      await orderService.updateOrderStatus(orderId, status);
      if (selectedOrder?.id === orderId) {
        setSelectedOrder(prev => prev ? { ...prev, status } : null);
      }
    } catch (error) {
      alert("Errore nell'aggiornamento dello stato");
    }
  };

  const updatePaymentStatus = async (orderId: string, status: Order['paymentStatus']) => {
    try {
      await orderService.updatePaymentStatus(orderId, status);
      if (selectedOrder?.id === orderId) {
        setSelectedOrder(prev => prev ? { ...prev, paymentStatus: status } : null);
      }
    } catch (error) {
      alert("Errore nell'aggiornamento del pagamento");
    }
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'pending': return { icon: <Clock className="h-4 w-4" />, label: 'In attesa', classes: 'bg-yellow-50 text-yellow-600 border-yellow-100' };
      case 'confirmed': return { icon: <CheckCircle className="h-4 w-4" />, label: 'Confermato', classes: 'bg-blue-50 text-blue-600 border-blue-100' };
      case 'delivering': return { icon: <Truck className="h-4 w-4" />, label: 'In consegna', classes: 'bg-purple-50 text-purple-600 border-purple-100' };
      case 'completed': return { icon: <CheckCircle className="h-4 w-4" />, label: 'Completato', classes: 'bg-green-50 text-green-600 border-green-100' };
      case 'cancelled': return { icon: <XCircle className="h-4 w-4" />, label: 'Annullato', classes: 'bg-red-50 text-red-600 border-red-100' };
      default: return { icon: <Clock className="h-4 w-4" />, label: status, classes: 'bg-gray-50 text-gray-600 border-gray-100' };
    }
  };

  if (loading) return <div className="p-8 text-center text-gray-500">Caricamento ordini...</div>;

  return (
    <div className={viewMode === 'grid' ? 'w-full px-4' : 'grid grid-cols-1 lg:grid-cols-3 gap-6'}>
      {/* Left Column or Full Width Grid */}
      <div className={`${viewMode === 'grid' ? 'w-full' : 'lg:col-span-1'} space-y-3 max-h-[85vh] overflow-y-auto pr-2 scrollbar-thin pb-20`}>
        <div className="flex flex-col gap-4 mb-6 sticky top-0 bg-gray-50/95 backdrop-blur z-20 py-4 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="font-bebas text-2xl text-brand-dark tracking-wide">Gestione Ordini ({orders.length})</h2>
          </div>
          
          <div className="flex bg-white rounded-xl p-1.5 border border-gray-200 shadow-sm max-w-md">
            <button 
              onClick={() => setViewMode('cards')}
              className={`flex-1 py-2 text-xs font-bold uppercase rounded-lg transition-all ${viewMode === 'cards' ? 'bg-brand-red text-white shadow-sm' : 'text-gray-400 hover:bg-gray-50'}`}
            >
              Vista Schede
            </button>
            <button 
              onClick={() => setViewMode('grid')}
              className={`flex-1 py-2 text-xs font-bold uppercase rounded-lg transition-all ${viewMode === 'grid' ? 'bg-brand-red text-white shadow-sm' : 'text-gray-400 hover:bg-gray-50'}`}
            >
              Log di Sistema
            </button>
          </div>
        </div>

        {orders.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-gray-200">
            <Package className="h-16 w-16 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-500 font-bold uppercase tracking-widest">Nessun ordine nel database.</p>
          </div>
        ) : viewMode === 'cards' ? (
          <div className="space-y-3">
            {orders.map((order) => {
              const statusConfig = getStatusConfig(order.status);
              const isSelected = selectedOrder?.id === order.id;
              
              return (
                <button
                  key={order.id}
                  onClick={() => handleOrderClick(order)}
                  className={`w-full text-left p-4 rounded-xl border transition-all ${
                    isSelected 
                      ? 'bg-brand-red/5 border-brand-red shadow-md ring-1 ring-brand-red/20' 
                      : 'bg-white border-gray-100 hover:border-brand-red/50 shadow-sm'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-mono font-bold text-gray-400">#{order.orderNumber}</span>
                    <div className="flex flex-col items-end">
                      <span className="text-base font-bebas text-brand-red">€{order.totalPrice.toFixed(2)}</span>
                      {order.scheduledTime && (
                        <div className="flex items-center gap-1 text-[10px] font-bold text-brand-dark bg-yellow-50 px-2 py-0.5 rounded-full border border-yellow-100 mt-1">
                          <Clock className="h-2.5 w-2.5 text-yellow-600" /> {order.scheduledTime}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="font-bold text-sm text-brand-dark truncate mb-3">
                    {order.customerInfo.firstName} {order.customerInfo.lastName}
                  </div>
                  <div className="flex justify-between items-center">
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full border text-[9px] font-bold uppercase ${statusConfig.classes}`}>
                      {statusConfig.icon}
                      {statusConfig.label}
                    </div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">
                      {order.deliveryType === 'delivery' ? 'Domicilio' : 'Ritiro'}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[900px]">
                <thead>
                  <tr className="bg-gray-50/50 border-b border-gray-100">
                    <th className="px-5 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Ordine / Data</th>
                    <th className="px-5 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Cliente</th>
                    <th className="px-5 py-4 text-[10px) font-bold text-gray-400 uppercase tracking-wider">Prodotti</th>
                    <th className="px-5 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider text-center">Fascia Oraria</th>
                    <th className="px-5 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider text-center">Stato</th>
                    <th className="px-5 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider text-right">Totale</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {orders.map((order) => {
                    const statusConfig = getStatusConfig(order.status);
                    const items = orderItemsMap[order.id] || [];
                    
                    return (
                      <tr 
                        key={order.id} 
                        onClick={() => handleOrderClick(order)}
                        className={`cursor-pointer transition-all ${selectedOrder?.id === order.id ? 'bg-red-50/50' : 'hover:bg-gray-50'}`}
                      >
                        <td className="px-5 py-4">
                          <div className="flex flex-col">
                            <span className="text-[10px] font-mono font-bold text-gray-400 leading-none mb-1">#{order.orderNumber}</span>
                            <span className="text-[9px] text-gray-400 uppercase">
                              {order.createdAt?.toDate?.()?.toLocaleString('it-IT', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }) || 
                               new Date(order.createdAt).toLocaleString('it-IT', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}
                            </span>
                          </div>
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex flex-col">
                            <span className="text-xs font-bold text-brand-dark">{order.customerInfo.firstName} {order.customerInfo.lastName}</span>
                            <span className="text-[10px] text-gray-400">{order.customerInfo.phone}</span>
                          </div>
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex flex-wrap gap-1 max-w-[250px]">
                            {fetchingAllItems && items.length === 0 ? (
                              <span className="text-[9px] text-gray-300 italic">Caricamento...</span>
                            ) : items.length > 0 ? (
                              items.map((item, idx) => (
                                <span key={idx} className="text-[10px] font-medium text-gray-600 bg-gray-100 px-1.5 py-0.5 rounded shadow-sm">
                                  {item.quantity}x {item.productName}
                                </span>
                              ))
                            ) : (
                              <span className="text-[10px] text-gray-300">Nessun dettaglio</span>
                            )}
                          </div>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-brand-red/5 border border-brand-red/10 text-brand-red text-xs font-bold whitespace-nowrap">
                            <Clock className="h-3 w-3" />
                            {order.scheduledTime || 'ASAP'}
                          </span>
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex justify-center flex-col items-center gap-1">
                            <div className={`flex items-center gap-1 px-3 py-1 rounded-full border text-[9px] font-bold uppercase whitespace-nowrap ${statusConfig.classes}`}>
                              {statusConfig.icon}
                              {statusConfig.label}
                            </div>
                            <span className={`text-[8px] font-bold uppercase tracking-wider ${order.paymentStatus === 'paid' ? 'text-green-500' : 'text-yellow-600'}`}>
                              {order.paymentStatus === 'paid' ? 'PAGATO' : 'DA PAGARE'}
                            </span>
                          </div>
                        </td>
                        <td className="px-5 py-4 text-right">
                          <span className="text-sm font-bebas text-brand-red">€{order.totalPrice.toFixed(2)}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Detail Column - Only in Cards mode */}
      {viewMode === 'cards' && (
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {selectedOrder ? (
              <motion.div
                key={selectedOrder.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xl space-y-6"
              >
                <div className="flex flex-wrap justify-between items-start gap-4 pb-4 border-b border-gray-100">
                  <div>
                    <h3 className="text-2xl font-bebas text-brand-dark tracking-wide">Ordine {selectedOrder.orderNumber}</h3>
                    <div className="flex items-center gap-3 mt-1">
                      <p className="text-xs text-gray-400">
                        {selectedOrder.createdAt?.toDate?.()?.toLocaleString() || new Date(selectedOrder.createdAt).toLocaleString()}
                      </p>
                      {selectedOrder.scheduledTime && (
                        <span className="text-xs font-bold text-brand-red bg-brand-red/5 px-2 py-0.5 rounded-full border border-brand-red/10 flex items-center gap-1">
                           <Clock className="h-3 w-3" /> Appuntamento: {selectedOrder.scheduledTime}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <select 
                      value={selectedOrder.status}
                      onChange={(e) => updateStatus(selectedOrder.id, e.target.value as Order['status'])}
                      className="text-xs font-bold uppercase p-2 rounded-lg border border-gray-200 bg-gray-50 focus:ring-2 focus:ring-brand-red outline-none"
                    >
                      <option value="pending">In attesa</option>
                      <option value="confirmed">Confermato</option>
                      <option value="delivering">In consegna</option>
                      <option value="completed">Completato</option>
                      <option value="cancelled">Annullato</option>
                    </select>
                    <select 
                      value={selectedOrder.paymentStatus}
                      onChange={(e) => updatePaymentStatus(selectedOrder.id, e.target.value as Order['paymentStatus'])}
                      className={`text-xs font-bold uppercase p-2 rounded-lg border outline-none ${
                          selectedOrder.paymentStatus === 'paid' ? 'bg-green-50 text-green-600 border-green-100' : 'bg-yellow-50 text-yellow-600 border-yellow-100'
                      }`}
                    >
                      <option value="unpaid">Non pagato</option>
                      <option value="paid">Pagato</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                        <User className="h-3 w-3" /> Cliente
                      </h4>
                      <p className="font-bold text-brand-dark">{selectedOrder.customerInfo.firstName} {selectedOrder.customerInfo.lastName}</p>
                      <p className="text-sm text-gray-600 flex items-center gap-1 mt-1">
                        <Phone className="h-3 w-3" /> {selectedOrder.customerInfo.phone}
                      </p>
                      <p className="text-sm text-gray-500 underline">{selectedOrder.customerInfo.email}</p>
                    </div>
                    {selectedOrder.deliveryType === 'delivery' && (
                      <div>
                        <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                          <MapPin className="h-3 w-3" /> Consegna
                        </h4>
                        <p className="text-sm font-medium text-brand-dark">
                          {selectedOrder.isForSomeoneElse ? selectedOrder.recipientInfo?.address : selectedOrder.customerInfo.address}
                        </p>
                        {selectedOrder.isForSomeoneElse && (
                          <p className="text-xs text-gray-500 mt-1">Recipiente: {selectedOrder.recipientInfo?.name} ({selectedOrder.recipientInfo?.phone})</p>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="space-y-4">
                      <div>
                          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                          <CreditCard className="h-3 w-3" /> Pagamento
                          </h4>
                          <p className="text-sm font-bold text-brand-dark uppercase">
                          {selectedOrder.paymentMethod === 'card' ? 'Carta di Credito (Online)' : 'Al momento della consegna'}
                          </p>
                      </div>
                      {selectedOrder.notes && (
                          <div>
                          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Note Cliente</h4>
                          <p className="text-sm text-brand-dark bg-yellow-50 p-3 rounded-xl border border-yellow-100 italic">
                              "{selectedOrder.notes}"
                          </p>
                          </div>
                      )}
                  </div>
                </div>

                <div>
                  <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 pb-2 border-b border-gray-50">Prodotti Ordinati</h4>
                  {loadingItems ? (
                    <div className="py-8 text-center text-gray-400 text-sm">Caricamento articoli...</div>
                  ) : (
                    <div className="space-y-3">
                      {orderItems.map((item) => (
                        <div key={item.id} className="flex justify-between items-start gap-4 animate-in fade-in slide-in-from-top-1">
                          <div className="flex-grow">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-brand-dark">{item.quantity}x</span>
                              <span className="font-bold text-brand-dark">{item.productName}</span>
                              <span className="text-[10px] text-gray-400 uppercase font-bold tracking-tighter self-center">
                                {item.configuration.variant === 'menu' ? 'MENÙ' : 'PANINO'}
                              </span>
                            </div>
                            <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1">
                              {item.configuration.removedIngredients.length > 0 && (
                                  <span className="text-[10px] text-red-500 font-bold">SENZA: {item.configuration.removedIngredients.join(', ')}</span>
                              )}
                              {item.configuration.addedExtras.length > 0 && (
                                  <span className="text-[10px] text-green-600 font-bold">EXTRA: {item.configuration.addedExtras.map(e => e.name).join(', ')}</span>
                              )}
                              {item.configuration.selectedFrySauces && item.configuration.selectedFrySauces.length > 0 && (
                                  <span className="text-[10px] text-gray-500">SALSE: {item.configuration.selectedFrySauces.join(', ')}</span>
                              )}
                            </div>
                            {item.configuration.notes && (
                              <p className="text-[10px] text-gray-400 italic mt-1 font-medium">Nota: {item.configuration.notes}</p>
                            )}
                          </div>
                          <span className="font-bebas text-brand-red text-lg">€{(item.priceAtPurchase * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                      <div className="pt-4 border-t border-brand-red/10 flex justify-between items-center font-bebas text-2xl text-brand-dark">
                          <span>Totale</span>
                          <span>€{selectedOrder.totalPrice.toFixed(2)}</span>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center py-20 bg-white/50 rounded-2xl border border-dashed border-gray-200">
                <Package className="h-16 w-16 text-gray-200 mb-4" />
                <p className="text-gray-400 font-bold uppercase tracking-widest text-sm">Seleziona un ordine per vedere i dettagli</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};

export default AdminOrders;
