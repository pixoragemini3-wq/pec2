import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { PRODUCTS } from '../constants';
import { CATEGORY_LABELS } from './CategoryNav';
import { X, LogOut, Package, Plus, Edit2, Trash2, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/auth-context';
import { auth } from '../lib/firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { productService } from '../services/productService';
import { authService } from '../services/authService';
import { settingsService, AppSettings } from '../services/settingsService';
import ProductEditor from './ProductEditor';
import AdminOrders from './AdminOrders';
import AdminScheduling from './AdminScheduling';
import { Settings, LayoutGrid, Square as SquareIcon, Calendar as CalendarIcon } from 'lucide-react';

interface AdminPanelProps {
  products: Product[];
  onToggleVisibility: (productId: number | string) => void;
  onRefresh: () => void;
  onClose: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ products, onToggleVisibility, onRefresh, onClose }) => {
  const { isAdmin, signOut, loading: authLoading } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [view, setView] = useState<'menu' | 'orders' | 'settings' | 'scheduling'>('menu');
  const [isSyncing, setIsSyncing] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string, type: 'success' | 'error' | 'info' } | null>(null);
  const [appSettings, setAppSettings] = useState<AppSettings>({ mobileColumns: 2, desktopColumns: 4 });
  const [isTestingTelegram, setIsTestingTelegram] = useState(false);

  useEffect(() => {
    if (isAdmin) {
      settingsService.getSettings().then(setAppSettings);
    }
  }, [isAdmin]);

  useEffect(() => {
    if (statusMessage) {
      const timer = setTimeout(() => setStatusMessage(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [statusMessage]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await signInWithEmailAndPassword(auth, username, password);
      setError('');
    } catch (err: any) {
      setError('Credenziali non valide o accesso non autorizzato');
    }
  };

  const handleSync = async () => {
    console.log("SYNC PROCESS START");
    setStatusMessage({ text: 'Inizio sincronizzazione...', type: 'info' });
    setIsSyncing(true);
    
    try {
      console.log("Invoking seedProducts with", PRODUCTS.length, "items");
      const result = await productService.seedProducts(PRODUCTS);
      
      if (result) {
        console.log("SYNC SUCCESS");
        setStatusMessage({ text: 'Prodotti sincronizzati con successo!', type: 'success' });
        onRefresh();
      } else {
        console.error("SYNC FAILED (returned false)");
        setStatusMessage({ text: 'Errore durante la sincronizzazione.', type: 'error' });
      }
    } catch (err) {
      console.error("SYNC FATAL ERROR:", err);
      const msg = err instanceof Error ? err.message : 'Errore sconosciuto';
      setStatusMessage({ text: `Errore: ${msg}`, type: 'error' });
    } finally {
      setIsSyncing(false);
    }
  };

  const handleTestTelegram = async () => {
    setIsTestingTelegram(true);
    setStatusMessage({ text: 'Invio test Telegram...', type: 'info' });
    try {
      const response = await fetch('/api/test-telegram');
      const data = await response.json();
      if (response.ok && data.ok) {
        setStatusMessage({ text: 'MESSAGGIO INVIATO! Verifica il tuo bot.', type: 'success' });
      } else {
        setStatusMessage({ text: `ERRORE: ${data.error || data.description || 'Configurazione non valida'}`, type: 'error' });
      }
    } catch (err) {
      setStatusMessage({ text: 'Errore di connessione al server.', type: 'error' });
    } finally {
      setIsTestingTelegram(false);
    }
  };

  const handleAddNew = () => {
    console.log("Opening New Product Editor");
    setIsAddingNew(true);
  };

  const handleDelete = async (productId: number | string) => {
    if (!confirm('Sei sicuro di voler eliminare questo prodotto?')) return;
    try {
      console.log(`Deleting product: ${productId}`);
      await productService.deleteProduct(productId);
      console.log('Product deleted successfully');
      setStatusMessage({ text: 'Prodotto eliminato!', type: 'success' });
      onRefresh();
    } catch (err) {
      console.error("Delete failed:", err);
      const msg = err instanceof Error ? err.message : 'Errore sconosciuto';
      const cleanMsg = msg.includes('{') ? JSON.parse(msg).error : msg;
      setStatusMessage({ text: `Errore eliminazione: ${cleanMsg}`, type: 'error' });
      alert('Errore durante l\'eliminazione: ' + cleanMsg);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await authService.signInWithGoogle();
      setError('');
    } catch (err: any) {
      if (err.code === 'auth/popup-closed-by-user') return;
      setError('Errore durante l\'accesso con Google');
    }
  };

  if (authLoading) return <div className="fixed inset-0 z-[110] bg-white flex items-center justify-center">Caricamento...</div>;

  if (!isAdmin) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
        <div className="bg-white rounded-2xl p-8 w-full max-w-md shadow-2xl relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
          
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bebas tracking-wide text-brand-red">Accesso Admin</h2>
            <p className="text-gray-500">Inserisci le credenziali per gestire il menù</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <button 
              type="button"
              onClick={handleGoogleLogin}
              className="w-full flex items-center justify-center gap-3 bg-white border border-gray-300 text-gray-700 py-3 rounded-xl font-bold hover:bg-gray-50 transition-all border-b-4 active:border-b-0 active:translate-y-[2px]"
            >
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="h-5 w-5" />
              Accedi con Google
            </button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">oppure con email</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input 
                type="email" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red focus:border-transparent outline-none transition-all"
                placeholder="admin@panecaffe.info"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red focus:border-transparent outline-none transition-all"
                placeholder="••••••••"
                required
              />
            </div>
            {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
            <button 
              type="submit"
              className="w-full bg-brand-red text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-brand-red/90 active:scale-[0.98] transition-all"
            >
              Accedi
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Group products by category for easier management
  const productsByCategory = products.reduce((acc, product) => {
    const category = product.category;
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(product);
    return acc;
  }, {} as Record<string, Product[]>);

  const categories = Object.keys(productsByCategory);

  return (
    <div className="fixed inset-0 z-[100] bg-brand-cream overflow-y-auto">
      <div className="sticky top-0 z-10 bg-white border-b border-gray-200 px-4 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-6">
          <h2 className="text-2xl font-bebas tracking-wide text-brand-red">Admin Area</h2>
          <nav className="flex gap-4">
            <button 
              onClick={() => setView('menu')}
              className={`text-sm font-bold uppercase transition-colors ${view === 'menu' ? 'text-brand-red border-b-2 border-brand-red' : 'text-gray-500 hover:text-brand-red'}`}
            >
              Menù
            </button>
            <button 
                onClick={() => setView('orders')}
                className={`text-sm font-bold uppercase transition-colors ${view === 'orders' ? 'text-brand-red border-b-2 border-brand-red' : 'text-gray-500 hover:text-brand-red'}`}
            >
              Ordini
            </button>
            <button 
                onClick={() => setView('scheduling')}
                className={`text-sm font-bold uppercase transition-colors ${view === 'scheduling' ? 'text-brand-red border-b-2 border-brand-red' : 'text-gray-500 hover:text-brand-red'}`}
            >
              Agenda
            </button>
            <button 
                onClick={() => setView('settings')}
                className={`text-sm font-bold uppercase transition-colors ${view === 'settings' ? 'text-brand-red border-b-2 border-brand-red' : 'text-gray-500 hover:text-brand-red'}`}
            >
              Impostazioni
            </button>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => signOut()}
            className="p-2 rounded-full hover:bg-red-50 text-red-500 transition-colors"
            title="Logout"
          >
            <LogOut className="h-5 w-5" />
          </button>
          <button 
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {view === 'menu' ? (
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
            {/* ... Gestione Menù content ... */}
            <div className="p-6 bg-gray-50 border-b border-gray-200 flex flex-col gap-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-bold text-gray-800">Gestione Menù</h3>
                  <p className="text-sm text-gray-500">Gestisci la visibilità e i dettagli dei prodotti.</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={handleSync}
                    disabled={isSyncing}
                    className="flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded-lg font-bold hover:bg-blue-600 transition-all text-sm disabled:opacity-50"
                    title="Importa prodotti dal file locale"
                  >
                    <RefreshCw className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} /> Sincronizza Locali
                  </button>
                  <button 
                    onClick={handleAddNew}
                    className="flex items-center gap-2 bg-brand-red text-white px-4 py-2 rounded-lg font-bold hover:bg-brand-red/90 transition-all text-sm"
                  >
                    <Plus className="h-4 w-4" /> Aggiungi Prodotto
                  </button>
                </div>
              </div>

              {statusMessage && (
                <div className={`flex items-center gap-2 px-4 py-3 rounded-xl animate-in slide-in-from-top-2 duration-300 ${
                  statusMessage.type === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 
                  statusMessage.type === 'error' ? 'bg-red-50 text-red-700 border border-red-100' : 
                  'bg-blue-50 text-blue-700 border border-blue-100'
                }`}>
                  {statusMessage.type === 'success' ? <CheckCircle2 className="h-4 w-4" /> : 
                   statusMessage.type === 'error' ? <AlertCircle className="h-4 w-4" /> : 
                   <RefreshCw className="h-4 w-4 animate-spin" />}
                  <span className="text-sm font-medium">{statusMessage.text}</span>
                </div>
              )}
            </div>

            <div className="divide-y divide-gray-100">
              {categories.map(category => (
                <div key={category} className="p-6">
                  <h4 className="text-brand-red font-bebas text-xl mb-4 tracking-wider">
                    {CATEGORY_LABELS[category as keyof typeof CATEGORY_LABELS] || category}
                  </h4>
                  <div className="space-y-4">
                    {productsByCategory[category].map(product => (
                      <div key={product.id} className="flex items-center justify-between py-2 group">
                        <div className="flex items-center gap-4">
                          <img 
                            src={product.image} 
                            alt={product.name} 
                            className="w-12 h-12 rounded-lg object-cover bg-gray-100"
                          />
                          <div>
                            <p className="font-bold text-gray-800">{product.name}</p>
                            <p className="text-xs text-gray-500">€{product.price.toFixed(2)}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <button 
                            onClick={() => setEditingProduct(product)}
                            className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all md:opacity-0 group-hover:opacity-100"
                            title="Modifica"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button 
                            onClick={() => handleDelete(product.id)}
                            className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all md:opacity-0 group-hover:opacity-100"
                            title="Elimina"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                          <button 
                            onClick={() => onToggleVisibility(product.id)}
                            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                              product.isVisible !== false ? 'bg-green-500' : 'bg-gray-300'
                            }`}
                          >
                            <span
                              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                product.isVisible !== false ? 'translate-x-6' : 'translate-x-1'
                              }`}
                            />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : view === 'orders' ? (
          <AdminOrders />
        ) : view === 'scheduling' ? (
          <AdminScheduling />
        ) : (
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
            <div className="flex items-center gap-3 mb-8">
              <div className="p-3 bg-brand-red/10 rounded-xl">
                <Settings className="h-6 w-6 text-brand-red" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800">Impostazioni App</h3>
                <p className="text-sm text-gray-500">Personalizza l'esperienza utente</p>
              </div>
            </div>

            <div className="space-y-8">
              <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <LayoutGrid className="h-5 w-5 text-gray-400" />
                  Layout Griglia (Mobile)
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => {
                      settingsService.updateSettings({ mobileColumns: 1 });
                      setAppSettings(prev => ({ ...prev, mobileColumns: 1 }));
                    }}
                    className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
                      appSettings.mobileColumns === 1 
                      ? 'border-brand-red bg-white shadow-md' 
                      : 'border-transparent bg-white/50 hover:bg-white text-gray-400'
                    }`}
                  >
                    <SquareIcon className="h-8 w-8" />
                    <span className="font-bold text-sm">1 Colonna</span>
                  </button>
                  <button
                    onClick={() => {
                      settingsService.updateSettings({ mobileColumns: 2 });
                      setAppSettings(prev => ({ ...prev, mobileColumns: 2 }));
                    }}
                    className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
                      appSettings.mobileColumns === 2 
                      ? 'border-brand-red bg-white shadow-md' 
                      : 'border-transparent bg-white/50 hover:bg-white text-gray-400'
                    }`}
                  >
                    <div className="flex gap-1">
                      <SquareIcon className="h-8 w-6" />
                      <SquareIcon className="h-8 w-6" />
                    </div>
                    <span className="font-bold text-sm">2 Colonne</span>
                  </button>
                </div>
                <p className="mt-4 text-xs text-gray-500 italic">
                  Cambia la disposizione dei prodotti sugli schermi piccoli. La modalità a 2 colonne ottimizza lo spazio.
                </p>
              </div>

              <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100 mt-6">
                <h4 className="font-bold text-blue-800 mb-2 flex items-center gap-2">
                  <RefreshCw className={`h-5 w-5 ${isTestingTelegram ? 'animate-spin' : ''}`} />
                  Test Notifiche Telegram
                </h4>
                <p className="text-sm text-blue-600 mb-4">
                  Premi il pulsante per verificare se il BOT e il Chat ID inseriti nei parametri sono corretti.
                </p>
                <button
                  onClick={handleTestTelegram}
                  disabled={isTestingTelegram}
                  className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isTestingTelegram ? 'Invio in corso...' : 'Invia Messaggio di Test'}
                </button>
              </div>

              <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <LayoutGrid className="h-5 w-5 text-gray-400" />
                  Layout Griglia (Desktop)
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => {
                      settingsService.updateSettings({ desktopColumns: 3 });
                      setAppSettings(prev => ({ ...prev, desktopColumns: 3 }));
                    }}
                    className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
                      appSettings.desktopColumns === 3 
                      ? 'border-brand-red bg-white shadow-md' 
                      : 'border-transparent bg-white/50 hover:bg-white text-gray-400'
                    }`}
                  >
                    <div className="flex gap-1">
                      <SquareIcon className="h-6 w-4" />
                      <SquareIcon className="h-6 w-4" />
                      <SquareIcon className="h-6 w-4" />
                    </div>
                    <span className="font-bold text-sm">3 Colonne</span>
                  </button>
                  <button
                    onClick={() => {
                      settingsService.updateSettings({ desktopColumns: 4 });
                      setAppSettings(prev => ({ ...prev, desktopColumns: 4 }));
                    }}
                    className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
                      appSettings.desktopColumns === 4 
                      ? 'border-brand-red bg-white shadow-md' 
                      : 'border-transparent bg-white/50 hover:bg-white text-gray-400'
                    }`}
                  >
                    <div className="flex gap-0.5">
                      <SquareIcon className="h-6 w-3" />
                      <SquareIcon className="h-6 w-3" />
                      <SquareIcon className="h-6 w-3" />
                      <SquareIcon className="h-6 w-3" />
                    </div>
                    <span className="font-bold text-sm">4 Colonne</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {(isAddingNew || editingProduct) && (
        <ProductEditor 
          product={editingProduct || undefined}
          onClose={() => {
            setIsAddingNew(false);
            setEditingProduct(null);
          }}
          onSave={() => {
            onRefresh();
          }}
        />
      )}
    </div>
  );
};

export default AdminPanel;
