import React, { useState } from 'react';
import { Product, ProductCategory } from '../types';
import { CATEGORY_LABELS } from './CategoryNav';
import { X, Upload, Plus, Minus, Loader2, Sparkles, Trash2, CheckSquare, Square, MinusCircle } from 'lucide-react';
import { productService } from '../services/productService';
import { geminiService, SuggestionResult } from '../services/geminiService';

interface ProductEditorProps {
  product?: Product;
  onClose: () => void;
  onSave: () => void;
}

const ProductEditor: React.FC<ProductEditorProps> = ({ product, onClose, onSave }) => {
  console.log("ProductEditor rendering, product:", product?.name || 'New');
  const [formData, setFormData] = useState<Partial<Product>>(
    product || {
      name: '',
      price: 0,
      description: '',
      image: '',
      category: 'hamburger',
      ingredients: [],
      removableIngredients: [],
      extras: [],
      variants: [],
      isVisible: true
    }
  );
  const [isSaving, setIsSaving] = useState(false);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<SuggestionResult | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [ingredientInput, setIngredientInput] = useState('');
  const [removableInput, setRemovableInput] = useState('');
  const [extraInput, setExtraInput] = useState({ name: '', price: 0 });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'price' || name === 'menuPrice' ? parseFloat(value) : value
    }));
  };

  const handleAddIngredient = (val?: string) => {
    const text = val || ingredientInput.trim();
    if (!text) return;
    setFormData(prev => ({
      ...prev,
      ingredients: Array.from(new Set([...(prev.ingredients || []), text]))
    }));
    setIngredientInput('');
  };

  const handleRemoveIngredient = (index: number) => {
    setFormData(prev => ({
      ...prev,
      ingredients: (prev.ingredients || []).filter((_, i) => i !== index)
    }));
  };

  const handleAddRemovable = (val?: string) => {
    const text = val || removableInput.trim();
    if (!text) return;
    setFormData(prev => ({
      ...prev,
      removableIngredients: Array.from(new Set([...(prev.removableIngredients || []), text]))
    }));
    setRemovableInput('');
  };

  const handleRemoveRemovable = (index: number) => {
    setFormData(prev => ({
      ...prev,
      removableIngredients: (prev.removableIngredients || []).filter((_, i) => i !== index)
    }));
  };

  const handleAddExtra = (val?: { name: string, price: number }) => {
    const data = val || extraInput;
    if (!data.name.trim()) return;
    setFormData(prev => ({
      ...prev,
      extras: [...(prev.extras || []), { ...data, name: data.name.trim() }]
    }));
    if (!val) setExtraInput({ name: '', price: 0 });
  };

  const handleRemoveExtra = (index: number) => {
    setFormData(prev => ({
      ...prev,
      extras: (prev.extras || []).filter((_, i) => i !== index)
    }));
  };

  const handleAiSuggest = async () => {
    if (!formData.name) {
      alert("Inserisci almeno il nome del prodotto per ricevere suggerimenti.");
      return;
    }
    setIsSuggesting(true);
    setAiSuggestions(null);
    try {
      const suggestions = await geminiService.suggestCustomizations(
        formData.name, 
        formData.description || ''
      );
      setAiSuggestions(suggestions);
    } catch (err) {
      console.error("Suggestion error:", err);
      alert("Impossibile ottenere suggerimenti al momento.");
    } finally {
      setIsSuggesting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    try {
      let imageUrl = formData.image;
      if (imageFile) {
        console.log("Uploading image...");
        try {
          imageUrl = await productService.uploadImage(imageFile);
          console.log("Image uploaded: ", imageUrl);
        } catch (uploadErr: any) {
          console.error("Upload error details:", uploadErr);
          throw new Error("Errore durante il caricamento dell'immagine: " + uploadErr.message);
        }
      }

      const productToSave = { ...formData, image: imageUrl };
      console.log("Saving product data:", productToSave);

      if (product?.id) {
        await productService.updateProduct(product.id, productToSave);
      } else {
        await productService.createProduct(productToSave as Omit<Product, 'id'>);
      }

      onSave();
      onClose();
    } catch (error: any) {
      console.error('Error saving product:', error);
      const msg = error instanceof Error ? error.message : 'Errore sconosciuto';
      const cleanMsg = msg.includes('{') ? JSON.parse(msg).error : msg;
      alert('Errore durante il salvataggio: ' + cleanMsg);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50">
          <h3 className="text-2xl font-bebas tracking-wide text-brand-red">
            {product ? 'Modifica Prodotto' : 'Nuovo Prodotto'}
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
            <X className="h-6 w-6 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Nome</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Prezzo (€)</label>
                  <input
                    type="number"
                    step="0.1"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Prezzo Menù (€)</label>
                  <input
                    type="number"
                    step="0.1"
                    name="menuPrice"
                    value={formData.menuPrice || ''}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red outline-none"
                    placeholder="Opzionale"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Categoria</label>
                <select
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red outline-none bg-white"
                >
                  {Object.entries(CATEGORY_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>{label}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Immagine</label>
                <div className="flex flex-col gap-4">
                  {formData.image && (
                    <img 
                      src={formData.image} 
                      alt="Preview" 
                      className="w-full h-32 object-cover rounded-xl border border-gray-200"
                    />
                  )}
                  <div className="flex items-center gap-2">
                    <input
                      type="file"
                      id="product-image"
                      accept="image/*"
                      onChange={(e) => setImageFile(e.target.files?.[0] || null)}
                      className="hidden"
                    />
                    <label
                      htmlFor="product-image"
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 rounded-xl hover:border-brand-red hover:bg-red-50 cursor-pointer transition-all text-sm text-gray-500 font-bold"
                    >
                      <Upload className="h-4 w-4" /> 
                      {imageFile ? imageFile.name : 'Carica Immagine'}
                    </label>
                  </div>
                  <input
                    type="text"
                    name="image"
                    value={formData.image}
                    onChange={handleInputChange}
                    placeholder="Oppure inserisci URL"
                    className="w-full px-4 py-2 rounded-xl border border-gray-200 text-xs focus:ring-2 focus:ring-brand-red outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Descrizione</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              rows={3}
              className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red outline-none resize-none"
            />
          </div>

          {/* Sezione IA Suggerimenti */}
          {aiSuggestions && (
            <div className="bg-blue-50/50 rounded-2xl border border-blue-100 p-4 space-y-4 animate-in slide-in-from-top-4">
              <div className="flex items-center gap-2 text-blue-600 mb-2">
                <Sparkles className="h-5 w-5" />
                <span className="font-bold text-sm">Suggerimenti IA per "{formData.name}"</span>
                <button 
                  type="button" 
                  onClick={() => setAiSuggestions(null)}
                  className="ml-auto p-1 hover:bg-blue-100 rounded-lg"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {aiSuggestions.suggestedIngredients.length > 0 && (
                <div>
                  <p className="text-[10px] uppercase font-black text-blue-400 mb-1.5 tracking-wider">Ingredienti Base</p>
                  <div className="flex flex-wrap gap-2">
                    {aiSuggestions.suggestedIngredients.map((ing, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => handleAddIngredient(ing)}
                        className="bg-white hover:bg-blue-600 hover:text-white px-3 py-1 rounded-full text-xs font-bold border border-blue-200 transition-all shadow-sm flex items-center gap-1 group"
                      >
                        <Plus className="h-3 w-3 group-hover:scale-125" /> {ing}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {aiSuggestions.suggestedRemovable.length > 0 && (
                <div>
                  <p className="text-[10px] uppercase font-black text-blue-400 mb-1.5 tracking-wider">Riduzioni (Rimuovibili)</p>
                  <div className="flex flex-wrap gap-2">
                    {aiSuggestions.suggestedRemovable.map((ing, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => handleAddRemovable(ing)}
                        className="bg-white hover:bg-red-600 hover:text-white px-3 py-1 rounded-full text-xs font-bold border border-red-200 transition-all shadow-sm flex items-center gap-1 group"
                      >
                        <Plus className="h-3 w-3 group-hover:scale-125" /> {ing}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {aiSuggestions.suggestedExtras.length > 0 && (
                <div>
                  <p className="text-[10px] uppercase font-black text-blue-400 mb-1.5 tracking-wider">Extra Consigliati</p>
                  <div className="flex flex-wrap gap-2">
                    {aiSuggestions.suggestedExtras.map((extra, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => handleAddExtra(extra)}
                        className="bg-white hover:bg-green-600 hover:text-white px-3 py-1 rounded-full text-xs font-bold border border-green-200 transition-all shadow-sm flex items-center gap-1 group"
                      >
                        <Plus className="h-3 w-3 group-hover:scale-125" /> 
                        {extra.name} <span className="opacity-60">({extra.price.toFixed(2)}€)</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="space-y-6">
            {/* 1. SEZIONE INGREDIENTI BASE */}
            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-sm font-black text-gray-800 uppercase tracking-tight">Ingredienti Base</h4>
                  <p className="text-[10px] text-gray-500 font-medium">Cosa compone il prodotto (non personalizzabile)</p>
                </div>
                {!aiSuggestions && (
                  <button 
                    type="button"
                    onClick={handleAiSuggest}
                    disabled={isSuggesting}
                    className="flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-700 transition-colors bg-white px-3 py-1.5 rounded-lg border border-blue-100 shadow-sm"
                  >
                    {isSuggesting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
                    Suggerisci
                  </button>
                )}
              </div>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={ingredientInput}
                    onChange={(e) => setIngredientInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddIngredient())}
                    className="flex-1 px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-red outline-none text-sm"
                    placeholder="Es: Hamburger di scottona, Cheddar..."
                  />
                  <button
                    type="button"
                    onClick={() => handleAddIngredient()}
                    className="p-2 bg-white hover:bg-gray-100 border border-gray-200 rounded-xl transition-colors shadow-sm"
                  >
                    <Plus className="h-5 w-5 text-gray-600" />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.ingredients?.map((ing, i) => (
                    <span key={i} className="flex items-center gap-1 bg-white px-3 py-1.5 rounded-full text-xs font-bold border border-gray-200 shadow-sm animate-in zoom-in-95">
                      {ing}
                      <button type="button" onClick={() => handleRemoveIngredient(i)} className="ml-1 text-gray-400 hover:text-brand-red transition-colors">
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                  {(!formData.ingredients || formData.ingredients.length === 0) && (
                    <p className="text-[10px] text-gray-300 font-medium italic py-2">Nessun ingrediente base definito.</p>
                  )}
                </div>
              </div>
            </div>

            {/* 2. SEZIONE RIDUZIONI */}
            <div className="p-4 bg-red-50/30 rounded-2xl border border-red-100">
              <div className="mb-4">
                <h4 className="text-sm font-black text-red-800 uppercase tracking-tight">Riduzioni (Rimuovibili)</h4>
                <p className="text-[10px] text-red-600 font-medium">Ingredienti che il cliente può scegliere di togliere</p>
              </div>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={removableInput}
                    onChange={(e) => setRemovableInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddRemovable())}
                    className="flex-1 px-4 py-2 rounded-xl border border-red-200 focus:ring-2 focus:ring-red-500 outline-none text-sm bg-white"
                    placeholder="Es: Cipolla, Maionese, Insalata..."
                  />
                  <button
                    type="button"
                    onClick={() => handleAddRemovable()}
                    className="p-2 bg-white hover:bg-red-100 border border-red-200 rounded-xl transition-colors shadow-sm"
                  >
                    <Plus className="h-5 w-5 text-red-600" />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {formData.removableIngredients?.map((ing, i) => (
                    <span key={i} className="flex items-center gap-1.5 bg-red-50 px-3 py-1.5 rounded-full text-xs font-bold border border-red-200 text-red-700 shadow-sm animate-in zoom-in-95">
                      <MinusCircle className="h-3 w-3 opacity-70" />
                      {ing}
                      <button type="button" onClick={() => handleRemoveRemovable(i)} className="ml-1 text-red-400 hover:text-red-700 transition-colors">
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                  {(!formData.removableIngredients || formData.removableIngredients.length === 0) && (
                    <p className="text-[10px] text-red-300 font-medium italic py-2">Nessuna riduzione definita.</p>
                  )}
                </div>
              </div>
            </div>

            {/* 3. SEZIONE EXTRA */}
            <div className="p-4 bg-green-50/30 rounded-2xl border border-green-100">
              <div className="mb-4">
                <h4 className="text-sm font-black text-green-800 uppercase tracking-tight">Extra Aggiungibili</h4>
                <p className="text-[10px] text-green-600 font-medium">Ingredienti a pagamento che il cliente può aggiungere</p>
              </div>
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    value={extraInput.name}
                    onChange={(e) => setExtraInput(prev => ({ ...prev, name: e.target.value }))}
                    className="sm:col-span-2 px-4 py-2 rounded-xl border border-green-200 focus:ring-2 focus:ring-green-500 outline-none text-sm bg-white"
                    placeholder="Nome extra (es. Doppia Carne)..."
                  />
                  <div className="flex gap-2">
                    <input
                      type="number"
                      step="0.1"
                      value={extraInput.price || ''}
                      onChange={(e) => setExtraInput(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                      className="flex-1 min-w-0 px-4 py-2 rounded-xl border border-green-200 focus:ring-2 focus:ring-green-500 outline-none text-sm bg-white"
                      placeholder="€"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddExtra()}
                      className="p-2 bg-white hover:bg-green-100 border border-green-200 rounded-xl transition-colors shrink-0 shadow-sm"
                    >
                      <Plus className="h-5 w-5 text-green-600" />
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {formData.extras?.map((extra, i) => (
                    <div key={i} className="flex items-center justify-between bg-white px-4 py-2 rounded-xl border border-green-100 shadow-sm animate-in slide-in-from-left-2">
                      <div className="flex flex-col">
                        <span className="text-[11px] font-black text-gray-800 uppercase tracking-tight">{extra.name}</span>
                        <span className="text-[10px] text-green-600 font-bold">+{extra.price.toFixed(2)}€</span>
                      </div>
                      <button 
                        type="button" 
                        onClick={() => handleRemoveExtra(i)}
                        className="p-1.5 text-gray-300 hover:text-green-700 hover:bg-green-50 rounded-lg transition-all"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
                {(!formData.extras || formData.extras.length === 0) && (
                  <p className="text-[10px] text-green-300 font-medium italic py-2 text-center">Nessun extra configurato.</p>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 rounded-xl font-bold text-gray-500 hover:bg-gray-100 transition-colors"
            >
              Annulla
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-8 py-3 bg-brand-red text-white rounded-xl font-bold shadow-lg hover:bg-brand-red/90 disabled:opacity-50 flex items-center gap-2"
            >
              {isSaving ? <Loader2 className="h-5 w-5 animate-spin" /> : null}
              {product ? 'Aggiorna Prodotto' : 'Crea Prodotto'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProductEditor;
